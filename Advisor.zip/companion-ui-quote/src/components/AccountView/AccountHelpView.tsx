import './AccountHelpView.css'

const ANALYZE_ICON_URL = '/ai-icon.svg'
const CHANGE_ARROW_ICON_URL = '/icons/arrow-up.svg'

const CUSTOMER_FACTS = [
  { icon: '/icons/loyalty.svg', label: '30 years, 4 months' },
  { icon: '/icons/cell-phone.svg', label: 'Samsung Galaxy S10e 128GB in Prism White' },
  { icon: '/icons/plan-perks.svg', label: 'Unlimited Plus' },
  { icon: '/icons/cell-phone.svg', label: '$649.99 to Upgrade' },
  { icon: '/icons/support.svg', label: 'Device Protection : Declined' },
  { icon: '/icons/lock-open.svg', label: 'SIM Protection : Not Enabled' },
  { icon: '/icons/reoccuring-payment.svg', label: 'BTA Limit : $750.00' },
  { icon: '/icons/credit-card.svg', label: 'Finance Limit: $5,152.74' },
  { icon: '/icons/credit-card.svg', label: 'Device Finance Limit: $2,000.00' },
]

const BILL_CHANGE_ROWS = [
  { label: 'New device installment – iPhone 16', value: '$33.33', trend: 'up' },
  { label: 'Disney+ bundle perk added', value: '$9.99', trend: 'up' },
  { label: 'Autopay & paperless discount', value: '$10.00', trend: 'down' },
  { label: 'Proration credit (plan change)', value: '$4.85', trend: 'down' },
  { label: 'Gov. taxes & surcharges', value: '$2.53', trend: 'up' },
]

type AccountHelpViewProps = {
  onAnalyzeBill?: () => void
}

export function AccountHelpView({ onAnalyzeBill }: AccountHelpViewProps) {
  return (
    <section className="account-help-view" aria-label="Account help overview">
      <aside className="account-help-view__bio">
        <div className="account-help-view__panel-title-row">
          <h2 className="account-help-view__panel-title">Customer Bio</h2>
        </div>

        <div className="account-help-view__segment" role="tablist" aria-label="Customer bio context">
          <button type="button" role="tab" aria-selected className="account-help-view__segment-btn account-help-view__segment-btn--active">
            Line
          </button>
          <button type="button" role="tab" aria-selected={false} className="account-help-view__segment-btn">
            Account
          </button>
        </div>

        <article className="account-help-view__line-card">
          <p className="account-help-view__line-name">Ben S Reyes</p>
          <p className="account-help-view__line-number">309-256-3658</p>
        </article>

        <ul className="account-help-view__facts">
          {CUSTOMER_FACTS.map((fact) => (
            <li key={fact.label}>
              {fact.icon
                ? <img src={fact.icon} alt="" className="account-help-view__fact-icon" />
                : <span className="account-help-view__fact-icon-placeholder" aria-hidden="true" />}
              {fact.label}
            </li>
          ))}
        </ul>
      </aside>

      <div className="account-help-view__main">
        <section className="account-help-view__actions">
          <h3 className="account-help-view__section-title">Actions</h3>
          <p className="account-help-view__note">
            Customer is eligible for 5G Home, but does not have the service.
          </p>
        </section>

        <section className="account-help-view__summary">
          <header className="account-help-view__summary-header">
            <h3 className="account-help-view__section-title">Bill Summary</h3>
            <button type="button" className="account-help-view__analyze-btn" onClick={onAnalyzeBill}>
              <img src={ANALYZE_ICON_URL} alt="" className="account-help-view__analyze-btn-icon" />
              <span>Analyze bill</span>
            </button>
          </header>

          <div className="account-help-view__summary-stats">
            <p><span>Balance Due:</span><br />$200.22</p>
            <p><span>Current balance:</span><br />$200.22</p>
            <p><span>Past due balance:</span><br />$0.00</p>
            <p><span>Last payment:</span><br />$195.80 on 03/10/2026</p>
          </div>

          <div className="account-help-view__summary-content">
            <div className="account-help-view__chart" aria-label="Bill trend chart placeholder">
              <div className="account-help-view__chart-labels">
                <span className="account-help-view__chart-label">$187.55</span>
                <span className="account-help-view__chart-label">$195.80</span>
                <span className="account-help-view__chart-label">$200.22</span>
              </div>
              <div className="account-help-view__bars" aria-hidden="true">
                <span />
                <span />
                <span />
              </div>
              <div className="account-help-view__line" aria-hidden="true" />
              <div className="account-help-view__chart-months">
                <span>Jan</span>
                <span>Feb</span>
                <span>Mar</span>
              </div>
            </div>

            <div className="account-help-view__changes">
              <p className="account-help-view__changes-title">Bill difference (Feb → Mar)</p>
              <ul>
                {BILL_CHANGE_ROWS.map((row) => (
                  <li key={row.label}>
                    <span>{row.label}</span>
                    <span className="account-help-view__change-value-wrap">
                      <img src={CHANGE_ARROW_ICON_URL} alt="" className="account-help-view__change-arrow" />
                      <strong className={`account-help-view__change-value account-help-view__change-value--${row.trend}`}>
                        {row.value}
                      </strong>
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <section className="account-help-view__recent">
          <h3 className="account-help-view__section-title">Recent Activity</h3>
        </section>
      </div>
    </section>
  )
}