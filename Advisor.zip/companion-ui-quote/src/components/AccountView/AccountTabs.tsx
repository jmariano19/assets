import './AccountTabs.css'

export type AccountTab = 'account-help' | 'device-help' | 'refund-exchange' | 'promotions'

interface AccountTabsProps {
  activeTab?: AccountTab
  onTabChange?: (tab: AccountTab) => void
}

const TABS: { id: AccountTab; label: string }[] = [
  { id: 'account-help', label: 'Account Help' },
  { id: 'device-help', label: 'Device Help' },
  { id: 'refund-exchange', label: 'Refund/Exchange' },
  { id: 'promotions', label: 'Promotions' },
]

export function AccountTabs({ activeTab = 'account-help', onTabChange }: AccountTabsProps) {
  const handleTabClick = (tab: AccountTab) => {
    onTabChange?.(tab)
  }

  return (
    <div className="account-tabs">
      <div className="account-tabs__container">
        <div className="account-tabs__list" role="tablist">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              role="tab"
              aria-selected={activeTab === tab.id}
              onClick={() => handleTabClick(tab.id)}
              className={`account-tabs__tab${activeTab === tab.id ? ' account-tabs__tab--active' : ''}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
