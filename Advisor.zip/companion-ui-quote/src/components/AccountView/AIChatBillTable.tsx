import './AIChatBillTable.css'

type AIChatBillTableRow = {
  line: string
  monthlyCost: string[]
}

type AIChatBillTableProps = {
  month: string
  rows: AIChatBillTableRow[]
  totalLabel: string
  totalAmount: string
  totalDescription: string
}

export function AIChatBillTable({
  month,
  rows,
  totalLabel,
  totalAmount,
  totalDescription,
}: AIChatBillTableProps) {
  return (
    <section className="ai-chat-bill-table" aria-label={`${month} bill details`}>
      <h3 className="ai-chat-bill-table__month">{month}</h3>

      <div className="ai-chat-bill-table__table" role="table" aria-label="Monthly cost by line">
        <div className="ai-chat-bill-table__header" role="rowgroup">
          <p className="ai-chat-bill-table__header-cell" role="columnheader">Line</p>
          <p className="ai-chat-bill-table__header-cell" role="columnheader">Monthly cost</p>
        </div>

        <div className="ai-chat-bill-table__separator" aria-hidden="true" />

        {rows.map((row, index) => {
          const isLastRow = index === rows.length - 1

          return (
            <div key={row.line} className="ai-chat-bill-table__row-wrapper" role="rowgroup">
              <div className="ai-chat-bill-table__row" role="row">
                <p className="ai-chat-bill-table__line" role="cell">{row.line}</p>
                <div className="ai-chat-bill-table__costs" role="cell">
                  {row.monthlyCost.map((cost) => (
                    <p key={cost} className="ai-chat-bill-table__cost-item">{cost}</p>
                  ))}
                </div>
              </div>

              {!isLastRow && (
                <div className="ai-chat-bill-table__separator" aria-hidden="true" />
              )}
            </div>
          )
        })}

        <div className="ai-chat-bill-table__separator" aria-hidden="true" />

        <div className="ai-chat-bill-table__row ai-chat-bill-table__row--total" role="row">
          <p className="ai-chat-bill-table__line" role="cell">{totalLabel}</p>
          <p className="ai-chat-bill-table__total" role="cell">
            <strong>{totalAmount}</strong> {totalDescription}
          </p>
        </div>
      </div>
    </section>
  )
}
