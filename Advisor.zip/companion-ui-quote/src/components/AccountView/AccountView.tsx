import { useEffect, useState } from 'react'
import { AccountAIDrawer } from './AccountAIDrawer'
import type { MonthlySummary } from './SelectionTiles'
import './AccountView.css'

const AI_INNER_ICON_URL = '/ai-white.svg'

type AccountViewProps = {
  showEntryPoint?: boolean
  openDrawerSignal?: number | null
  onOrderTransitionToOrder?: (summary: MonthlySummary) => void
}

export function AccountView({ showEntryPoint = true, openDrawerSignal, onOrderTransitionToOrder }: AccountViewProps) {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false)
  const [isClosing, setIsClosing] = useState(false)

  const handleCloseDrawer = () => {
    if (!isDrawerOpen || isClosing) {
      return
    }

    setIsClosing(true)
    setTimeout(() => {
      setIsDrawerOpen(false)
      setIsClosing(false)
    }, 300)
  }

  const handleToggle = () => {
    if (isDrawerOpen) {
      handleCloseDrawer()
    } else {
      setIsClosing(false)
      setIsDrawerOpen(true)
    }
  }

  useEffect(() => {
    if (openDrawerSignal === null || openDrawerSignal === undefined) {
      return
    }

    setIsClosing(false)
    setIsDrawerOpen(true)
  }, [openDrawerSignal])

  return (
    <>
      {showEntryPoint && (
        <button
          type="button"
          className="account-view__ai-fab"
          onClick={handleToggle}
          aria-label={isDrawerOpen ? 'Close AI drawer' : 'Open AI drawer'}
          aria-expanded={isDrawerOpen}
          aria-controls="account-ai-drawer"
        >
          <img src={AI_INNER_ICON_URL} alt="" className="account-view__ai-fab-icon" />
        </button>
      )}

      <AccountAIDrawer
        isOpen={isDrawerOpen}
        isClosing={isClosing}
        onClose={handleCloseDrawer}
        onOrderTransitionToOrder={onOrderTransitionToOrder}
      />
    </>
  )
}
