import { useEffect, useMemo, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import './SelectionTiles.css'

export type SelectionTileLine = {
  id: string
  label: string
}

export type SelectionTileNote = {
  id: string
  tone: 'positive' | 'negative'
  text: string
}

export type SelectionTile = {
  id: string
  title: string
  subtitle: string
  thumbnail?: string
  icon?: string
  linePrompt?: string
  lineOptions?: SelectionTileLine[]
  defaultSelectedLineIds?: string[]
  notes?: SelectionTileNote[]
}

export type MonthlySummary = {
  previousMonthlyTotal: number
  newMonthlyTotal: number
  totalSavings: number
}

type SelectionTilesProps = {
  tiles: SelectionTile[]
  onApplyComplete?: (summary: MonthlySummary) => void
  footerBeforeApply?: ReactNode
}

const LINE_ICON_URL = '/icons/cell-phone.svg'
const POSITIVE_NOTE_ICON_URL = '/icons/checkmark.svg'
const NEGATIVE_NOTE_ICON_URL = '/icons/close-alt.svg'
const SHOP_ICON_URL = '/icons/shop.svg'
const CURRENT_MONTHLY_TOTAL = 200.22

function parseSavingsAmount(subtitle: string) {
  const match = subtitle.match(/\$(\d+(?:\.\d+)?)/)
  return match ? Number(match[1]) : 0
}

function formatCurrency(amount: number) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount)
}

export function SelectionTiles({ tiles, onApplyComplete, footerBeforeApply }: SelectionTilesProps) {
  const defaultSelectedLines = useMemo(
    () => Object.fromEntries(tiles.map((tile) => [tile.id, tile.defaultSelectedLineIds ?? []])) as Record<string, string[]>,
    [tiles],
  )

  const [selectedTileIds, setSelectedTileIds] = useState<string[]>([])
  const [selectedLineIdsByTile, setSelectedLineIdsByTile] = useState<Record<string, string[]>>(defaultSelectedLines)
  const [isApplying, setIsApplying] = useState(false)
  const applyTimeoutRef = useRef<number | null>(null)

  const totalSavings = useMemo(() => {
    return selectedTileIds.reduce((total, tileId) => {
      const tile = tiles.find((entry) => entry.id === tileId)
      if (!tile) {
        return total
      }

      const savingsAmount = parseSavingsAmount(tile.subtitle)
      const selectedLineCount = tile.lineOptions?.length ? Math.max((selectedLineIdsByTile[tileId] ?? []).length, 1) : 1
      return total + savingsAmount * selectedLineCount
    }, 0)
  }, [selectedLineIdsByTile, selectedTileIds, tiles])

  const newMonthlyTotal = Math.max(CURRENT_MONTHLY_TOTAL - totalSavings, 0)

  useEffect(() => {
    return () => {
      if (applyTimeoutRef.current !== null) {
        window.clearTimeout(applyTimeoutRef.current)
        applyTimeoutRef.current = null
      }
    }
  }, [])

  const handleTileToggle = (tile: SelectionTile) => {
    if (isApplying) {
      return
    }

    const isSelected = selectedTileIds.includes(tile.id)

    if (isSelected) {
      setSelectedTileIds((current) => current.filter((id) => id !== tile.id))
      setSelectedLineIdsByTile((current) => ({ ...current, [tile.id]: [] }))
      return
    }

    setSelectedTileIds((current) => [...current, tile.id])

    if (tile.lineOptions?.length) {
      setSelectedLineIdsByTile((current) => ({
        ...current,
        [tile.id]: current[tile.id]?.length ? current[tile.id] : tile.defaultSelectedLineIds ?? [],
      }))
    }
  }

  const handleLineToggle = (tileId: string, lineId: string) => {
    if (isApplying) {
      return
    }

    setSelectedLineIdsByTile((current) => {
      const currentLines = current[tileId] ?? []
      const nextLines = currentLines.includes(lineId)
        ? currentLines.filter((id) => id !== lineId)
        : [...currentLines, lineId]

      return {
        ...current,
        [tileId]: nextLines,
      }
    })
  }

  const handleApply = () => {
    if (!selectedTileIds.length || isApplying) {
      return
    }

    setIsApplying(true)

    applyTimeoutRef.current = window.setTimeout(() => {
      if (onApplyComplete) {
        onApplyComplete({ previousMonthlyTotal: CURRENT_MONTHLY_TOTAL, newMonthlyTotal, totalSavings })
      } else {
        setIsApplying(false)
      }
      applyTimeoutRef.current = null
    }, 2200)
  }

  return (
    <div className="ai-selection-tiles" aria-label="Savings options">
      {tiles.map((tile, tileIndex) => {
        const hasExpandableContent = Boolean(tile.lineOptions?.length || tile.notes?.length)
        const isSelected = selectedTileIds.includes(tile.id)
        const isExpanded = isSelected && hasExpandableContent
        const selectedLineIds = selectedLineIdsByTile[tile.id] ?? []

        return (
          <div
            key={tile.id}
            className={`ai-selection-tiles__tile ai-selection-tiles__tile--stagger${isSelected ? ' ai-selection-tiles__tile--selected' : ''}${isExpanded ? ' ai-selection-tiles__tile--expanded' : ''}`}
            style={{ animationDelay: `${tileIndex * 120}ms` }}
          >
            <button
              type="button"
              className="ai-selection-tiles__summary"
              onClick={() => handleTileToggle(tile)}
              aria-pressed={isSelected}
              aria-expanded={tile.lineOptions?.length ? isExpanded : undefined}
              disabled={isApplying}
            >
              <div className="ai-selection-tiles__media">
                {tile.thumbnail ? (
                  <img src={tile.thumbnail} alt="" className="ai-selection-tiles__thumbnail" />
                ) : (
                  <div className="ai-selection-tiles__icon-wrap" aria-hidden="true">
                    <img src={tile.icon} alt="" className="ai-selection-tiles__icon" />
                  </div>
                )}
              </div>

              <div className="ai-selection-tiles__copy">
                <p className="ai-selection-tiles__title">{tile.title}</p>
                <p className="ai-selection-tiles__subtitle">{tile.subtitle}</p>
              </div>

              <span
                className={`ai-selection-tiles__checkbox${isSelected ? ' ai-selection-tiles__checkbox--selected' : ''}`}
                aria-hidden="true"
              />
            </button>

            {hasExpandableContent && (
              <div
                className={`ai-selection-tiles__details-shell${isExpanded ? ' ai-selection-tiles__details-shell--expanded' : ''}`}
                aria-hidden={!isExpanded}
              >
                <div className={`ai-selection-tiles__details${isExpanded ? ' ai-selection-tiles__details--expanded' : ''}`}>
                <div className="ai-selection-tiles__divider" aria-hidden="true" />

                {tile.lineOptions?.length ? (
                  <>
                    <p className="ai-selection-tiles__helper">{tile.linePrompt ?? 'Select lines to apply'}</p>
                    <div className="ai-selection-tiles__lines">
                      {tile.lineOptions.map((line) => {
                        const isLineSelected = selectedLineIds.includes(line.id)

                        return (
                          <button
                            key={line.id}
                            type="button"
                            className="ai-selection-tiles__line"
                            onClick={() => handleLineToggle(tile.id, line.id)}
                            aria-pressed={isLineSelected}
                            disabled={isApplying}
                          >
                            <span className="ai-selection-tiles__line-copy">
                              <img src={LINE_ICON_URL} alt="" className="ai-selection-tiles__line-icon" />
                              <span className="ai-selection-tiles__line-label">{line.label}</span>
                            </span>
                            <span
                              className={`ai-selection-tiles__checkbox${isLineSelected ? ' ai-selection-tiles__checkbox--selected' : ''}`}
                              aria-hidden="true"
                            />
                          </button>
                        )
                      })}
                    </div>
                  </>
                ) : null}

                {tile.notes?.length ? (
                  <>
                    <div className="ai-selection-tiles__divider" aria-hidden="true" />
                    <div className="ai-selection-tiles__notes">
                      {tile.notes.map((note) => (
                        <div key={note.id} className="ai-selection-tiles__note">
                          <img
                            src={note.tone === 'positive' ? POSITIVE_NOTE_ICON_URL : NEGATIVE_NOTE_ICON_URL}
                            alt=""
                            className="ai-selection-tiles__note-icon"
                            aria-hidden="true"
                          />
                          <p className="ai-selection-tiles__note-text">{note.text}</p>
                        </div>
                      ))}
                    </div>
                  </>
                ) : null}
                </div>
              </div>
            )}
          </div>
        )
      })}

      {selectedTileIds.length > 0 && (
        <section className="ai-selection-tiles__pricing" aria-label="Pricing overview">
          <div className="ai-selection-tiles__pricing-grid">
            <div className="ai-selection-tiles__pricing-card">
              <span className="ai-selection-tiles__pricing-label">Current monthly</span>
              <strong className="ai-selection-tiles__pricing-value">{formatCurrency(CURRENT_MONTHLY_TOTAL)}</strong>
            </div>
            <div className="ai-selection-tiles__pricing-card ai-selection-tiles__pricing-card--accent">
              <span className="ai-selection-tiles__pricing-label">New monthly</span>
              <strong className="ai-selection-tiles__pricing-value">{formatCurrency(newMonthlyTotal)}</strong>
            </div>
            <div className="ai-selection-tiles__pricing-card">
              <span className="ai-selection-tiles__pricing-label">Savings</span>
              <strong className="ai-selection-tiles__pricing-value ai-selection-tiles__pricing-value--positive">{formatCurrency(totalSavings)}</strong>
            </div>
          </div>
        </section>
      )}

      {footerBeforeApply}

      {selectedTileIds.length > 0 && (
        <div className="account-view__button-group ai-selection-tiles__apply-group">
          <button
            type="button"
            className="account-view__pill-btn ai-selection-tiles__apply-btn"
            onClick={handleApply}
            disabled={isApplying}
          >
            {isApplying ? (
              <span className="ai-selection-tiles__spinner" aria-hidden="true" />
            ) : (
              <img src={SHOP_ICON_URL} alt="" className="ai-selection-tiles__apply-icon" aria-hidden="true" />
            )}
            <span>{isApplying ? 'Preparing order...' : 'Apply and continue'}</span>
          </button>
        </div>
      )}
    </div>
  )
}
