import { useState, useRef, useEffect } from 'react'
import type { ReactNode } from 'react'
import { SelectionTiles, type SelectionTile, type MonthlySummary } from './SelectionTiles'

const SPARKLE_ICON_URL = '/ai-icon.svg'
const CLOSE_ICON_URL = '/icons/close.svg'
const ELLIPSIS_HZ_ICON_URL = '/icons/ellipsis-hz.svg'
const MIC_ICON_URL = '/icons/mic.svg'
const SEND_ICON_URL = '/icons/arrow-up.svg'
const UP_ARROW_ICON_URL = '/icons/arrow-up.svg'
const PLUS_ICON_URL = '/icons/plus.svg'
const THUMBS_UP_ICON_URL = '/icons/thumbs-up.svg'
const THUMBS_DOWN_ICON_URL = '/icons/thumbs-down.svg'
const FEEDBACK_ELLIPSIS_ICON_URL = '/icons/ellipsis.svg'

function FeedbackRow() {
  const [voted, setVoted] = useState<'up' | 'down' | null>(null)
  return (
    <div className="account-view__feedback">
      <button
        type="button"
        className={`account-view__feedback-btn${voted === 'up' ? ' account-view__feedback-btn--active' : ''}`}
        aria-label="Thumbs up"
        onClick={() => setVoted(v => v === 'up' ? null : 'up')}
      >
        <img src={THUMBS_UP_ICON_URL} alt="" />
      </button>
      <button
        type="button"
        className={`account-view__feedback-btn${voted === 'down' ? ' account-view__feedback-btn--active' : ''}`}
        aria-label="Thumbs down"
        onClick={() => setVoted(v => v === 'down' ? null : 'down')}
      >
        <img src={THUMBS_DOWN_ICON_URL} alt="" />
      </button>
      <button
        type="button"
        className="account-view__feedback-btn"
        aria-label="More options"
      >
        <img src={FEEDBACK_ELLIPSIS_ICON_URL} alt="" />
      </button>
    </div>
  )
}

type BillChangeItem = { line: string; description: string; amount: string }

const BILL_CHANGE_ITEMS: BillChangeItem[] = [
  { line: 'Account', description: 'Auto Pay set to off', amount: '$10.00' },
  { line: '••• 0234', description: 'Monthly device payment', amount: '$19.50' },
  { line: '••• 0488', description: 'Proration on previous bill', amount: '$5.75' },
]

function BillChangesWidget({ stagger }: { stagger?: boolean }) {
  return (
    <div className={`bill-changes-widget${stagger ? ' bill-changes-widget--stagger' : ''}`}>
      <div className="bill-changes-widget__header">
        <span className="bill-changes-widget__title">What changed</span>
        <span className="bill-changes-widget__period">Feb - March</span>
      </div>
      {BILL_CHANGE_ITEMS.map((item, i) => (
        <div key={item.description}>
          {i > 0 && <div className="bill-changes-widget__divider" aria-hidden="true" />}
          <div className="bill-changes-widget__row">
            <div className="bill-changes-widget__row-left">
              <span className="bill-changes-widget__line">{item.line}</span>
              <span className="bill-changes-widget__desc">{item.description}</span>
            </div>
            <div className="bill-changes-widget__amount-group">
              <img src={UP_ARROW_ICON_URL} alt="increased" className="bill-changes-widget__up-arrow" />
              <span className="bill-changes-widget__amount">{item.amount}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

const EXPLORE_SAVINGS_TILES: SelectionTile[] = [
  {
    id: 'disney-bundle',
    title: 'Add Disney+, ESPN, Hulu (With Ads)',
    subtitle: 'Save $9.99/mo',
    thumbnail: '/thumbnails/disney.png',
    linePrompt: 'Select lines to apply',
    lineOptions: [
      { id: '0234', label: '••• 0234' },
      { id: '0488', label: '••• 0488' },
      { id: '0655', label: '••• 0655' },
    ],
    defaultSelectedLineIds: ['0234'],
    notes: [
      { id: 'base-rate', tone: 'positive', text: 'Saves compared to paying for Disney+ separately' },
      { id: 'hotspot', tone: 'negative', text: 'Adds to this bill' },
    ],
  },
  {
    id: 'autopay-paperless',
    title: 'Enroll in Autopay & Paperless Billing',
    subtitle: 'Save $10.00/mo',
    icon: '/icons/reoccuring-payment.svg',
  },
  {
    id: 'unlimited-welcome',
    title: 'Switch to Unlimited Welcome',
    subtitle: 'Save $15.00/mo',
    thumbnail: '/thumbnails/unlimited-plan.png',
  },
]

const ACTION_RESPONSES: Record<string, ReactNode> = {
  'Explore savings': (
    <>
      <h3 className="account-view__title">Here are the available ways to lower the monthly total</h3>
      <p className="account-view__text">
        Recommended based on Ben’s current plan and service usage. Select the options you would like to apply.
      </p>
      <SelectionTiles tiles={EXPLORE_SAVINGS_TILES} />
    </>
  ),
  'Explore offers': (
    <>
      <p className="account-view__text">
        There are <strong>2 active promotions</strong> available on Ben's account right now:
      </p>
      <p className="account-view__text">
        <strong>iPhone 16 trade-in deal</strong> — Get up to <strong>$830 off</strong> a new iPhone 16 with an eligible trade-in on any Unlimited plan.
      </p>
      <p className="account-view__text">
        <strong>Free smartwatch</strong> — Add a new line and get a free Galaxy Watch 7 with activation.
      </p>
      <div className="account-view__button-group">
        <button type="button" className="account-view__pill-btn">See iPhone deal</button>
        <button type="button" className="account-view__pill-btn">Add a line</button>
      </div>
    </>
  ),
  'Upgrade a line': (
    <>
      <p className="account-view__text">
        All 3 lines on Ben's account are upgrade-eligible. Here's a quick summary:
      </p>
      <p className="account-view__text">
        <strong>Line 1 (Ben)</strong> — iPhone 13 Pro · Eligible since Jan 2025<br />
        <strong>Line 2 (Sara)</strong> — Pixel 8 · Eligible since Mar 2025<br />
        <strong>Line 3 (Jake)</strong> — iPhone SE · Eligible since Nov 2024
      </p>
      <p className="account-view__text">Which line would you like to upgrade?</p>
      <div className="account-view__button-group">
        <button type="button" className="account-view__pill-btn">Upgrade Ben</button>
        <button type="button" className="account-view__pill-btn">Upgrade Sara</button>
        <button type="button" className="account-view__pill-btn">Upgrade Jake</button>
      </div>
    </>
  ),
}

type TextSegment = { text: string; bold?: boolean }

const PARA1_SEGMENTS: TextSegment[] = [
  { text: "Ben's bill increased by " },
  { text: '$35.22', bold: true },
  { text: ' with several changes, including a new device payment, Auto Pay change, and an additional service.' },
]
const PARA2_SEGMENTS: TextSegment[] = [
  { text: 'Would you like to explore ways to reduce the monthly cost?' },
]

function segmentsToPlain(segs: TextSegment[]) {
  return segs.map(s => s.text).join('')
}

function renderSegments(segs: TextSegment[], visibleChars: number): ReactNode {
  const nodes: ReactNode[] = []
  let remaining = visibleChars
  for (const seg of segs) {
    if (remaining <= 0) break
    const slice = seg.text.slice(0, remaining)
    nodes.push(seg.bold ? <b key={seg.text}>{slice}</b> : slice)
    remaining -= seg.text.length
  }
  return <>{nodes}</>
}

function renderStreamedParagraphs(lines: string[], visibleChars: number, className = 'account-view__text'): ReactNode[] {
  const nodes: ReactNode[] = []
  let remaining = visibleChars

  for (const line of lines) {
    if (remaining <= 0) break

    const visibleText = line.slice(0, remaining)
    nodes.push(
      <p key={line} className={className}>
        {visibleText}
      </p>
    )
    remaining -= line.length
  }

  return nodes
}

const STREAM_PARA1 = segmentsToPlain(PARA1_SEGMENTS)
const STREAM_PARA2 = segmentsToPlain(PARA2_SEGMENTS)
const STREAM_HEADER = 'Bill overview'
const STREAM_FULL = STREAM_HEADER + '\n' + STREAM_PARA1 + '\n' + STREAM_PARA2

const RESP_HEADING = 'Here are the available ways to lower the monthly total'
const RESP_BODY = "Recommended based on Ben's current plan and service usage. Select the options you would like to apply."
const RESP_FULL = RESP_HEADING + '\n' + RESP_BODY

const BILL_CHANGES_HEADING = "Here's what changed on Ben's bill"
const BILL_CHANGES_BODY = "Ben's bill increased by $35.25 this cycle. The changes below account for the full difference from last month."
const BILL_CHANGES_FULL = BILL_CHANGES_HEADING + '\n' + BILL_CHANGES_BODY
const FOLLOW_UP_ACTIONS = ['Show ways to save', 'Restore Auto Pay', 'Explore offers']
const WELCOME_ACTIONS = ['Show bill overview', ...FOLLOW_UP_ACTIONS]
const WELCOME_HEADER = 'How can I help you today?'
const WELCOME_BODY = 'I can support with questions about the customer bill.'

const PRORATION_HEADING = 'What proration means'
const PRORATION_LINES = [
  'Proration is a one-time partial charge or credit that appears when service changes happen in the middle of a billing cycle.',
  'This usually happens when a line changes plan or when a feature is added or removed between bill dates.',
  'For example, if a plan changes halfway through the month, the bill may show part of the old rate and part of the new rate for that cycle.',
  'The next bill usually returns to the standard monthly amount.',
]
const PRORATION_FULL = PRORATION_HEADING + '\n' + PRORATION_LINES.join('')

type CompletedTurn = {
  id: number
  action: string
  content: ReactNode
}

type AccountAIDrawerProps = {
  isOpen: boolean
  isClosing: boolean
  onClose: () => void
  onOrderTransitionToOrder?: (summary: MonthlySummary) => void
}

export function AccountAIDrawer({ isOpen, isClosing, onClose, onOrderTransitionToOrder }: AccountAIDrawerProps) {
  const [isOptionsMenuOpen, setIsOptionsMenuOpen] = useState(false)
  const [defaultView, setDefaultView] = useState<'overview' | 'welcome'>('overview')
  const [inputValue, setInputValue] = useState('')
  const [inputFocused, setInputFocused] = useState(false)
  const [chatResetAnimation, setChatResetAnimation] = useState<'idle' | 'fade-out' | 'fade-in'>('idle')
  const [completedTurns, setCompletedTurns] = useState<CompletedTurn[]>([])
  const [activeTurnId, setActiveTurnId] = useState<number | null>(null)
  const [activeTurnAction, setActiveTurnAction] = useState<string | null>(null)
  const [activeResponseType, setActiveResponseType] = useState<'overview' | 'resp' | 'bill-changes' | 'proration' | 'static' | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [responseContent, setResponseContent] = useState<ReactNode | null>(null)
  const [isInitialLoading, setIsInitialLoading] = useState(true)
  const [streamedChars, setStreamedChars] = useState(0)
  const [streamPhase, setStreamPhase] = useState<'idle' | 'streaming' | 'done'>('idle')
  const [respStreamedChars, setRespStreamedChars] = useState(0)
  const [respStreamPhase, setRespStreamPhase] = useState<'idle' | 'streaming' | 'done'>('idle')
  const [billChangesStreamedChars, setBillChangesStreamedChars] = useState(0)
  const [billChangesStreamPhase, setBillChangesStreamPhase] = useState<'idle' | 'streaming' | 'done'>('idle')
  const [prorationStreamedChars, setProrationStreamedChars] = useState(0)
  const [prorationStreamPhase, setProrationStreamPhase] = useState<'idle' | 'streaming' | 'done'>('idle')
  const scrollAreaRef = useRef<HTMLDivElement>(null)
  const selectedActionRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const generationTimeoutRef = useRef<number | null>(null)
  const resetStepTimeoutRef = useRef<number | null>(null)
  const resetCompleteTimeoutRef = useRef<number | null>(null)
  const initialLoadTimeoutRef = useRef<number | null>(null)

  const clearGenerationTimeout = () => {
    if (generationTimeoutRef.current !== null) {
      window.clearTimeout(generationTimeoutRef.current)
      generationTimeoutRef.current = null
    }
  }

  const clearResetTransitionTimeouts = () => {
    if (resetStepTimeoutRef.current !== null) {
      window.clearTimeout(resetStepTimeoutRef.current)
      resetStepTimeoutRef.current = null
    }
    if (resetCompleteTimeoutRef.current !== null) {
      window.clearTimeout(resetCompleteTimeoutRef.current)
      resetCompleteTimeoutRef.current = null
    }
  }

  const resetChatToDefault = () => {
    clearGenerationTimeout()
    setDefaultView('overview')
    setCompletedTurns([])
    setActiveTurnId(null)
    setActiveTurnAction(null)
    setActiveResponseType(null)
    setIsGenerating(false)
    setResponseContent(null)
    setStreamedChars(0)
    setStreamPhase('done')
    setRespStreamedChars(0)
    setRespStreamPhase('idle')
    setBillChangesStreamedChars(0)
    setBillChangesStreamPhase('idle')
    setProrationStreamedChars(0)
    setProrationStreamPhase('idle')
  }

  const scrollToTop = () => {
    scrollAreaRef.current?.scrollTo({ top: 0, behavior: 'auto' })
  }

  useEffect(() => {
    if (activeTurnId && scrollAreaRef.current && selectedActionRef.current) {
      const scrollArea = scrollAreaRef.current
      const target = selectedActionRef.current
      scrollArea.scrollTo({ top: target.offsetTop, behavior: 'smooth' })
    }
  }, [activeTurnId])

  useEffect(() => {
    if (respStreamPhase !== 'streaming') return
    if (respStreamedChars >= RESP_FULL.length) {
      setRespStreamPhase('done')
      return
    }
    const t = window.setTimeout(() => setRespStreamedChars(c => c + 1), 12)
    return () => window.clearTimeout(t)
  }, [respStreamPhase, respStreamedChars])

  useEffect(() => {
    if (billChangesStreamPhase !== 'streaming') return
    if (billChangesStreamedChars >= BILL_CHANGES_FULL.length) {
      setBillChangesStreamPhase('done')
      return
    }
    const t = window.setTimeout(() => setBillChangesStreamedChars(c => c + 1), 12)
    return () => window.clearTimeout(t)
  }, [billChangesStreamPhase, billChangesStreamedChars])

  useEffect(() => {
    if (prorationStreamPhase !== 'streaming') return
    if (prorationStreamedChars >= PRORATION_FULL.length) {
      setProrationStreamPhase('done')
      return
    }
    const t = window.setTimeout(() => setProrationStreamedChars(c => c + 1), 12)
    return () => window.clearTimeout(t)
  }, [prorationStreamPhase, prorationStreamedChars])

  useEffect(() => {
    if (isInitialLoading) return
    setStreamedChars(0)
    setStreamPhase('streaming')
  }, [isInitialLoading])

  useEffect(() => {
    if (streamPhase !== 'streaming') return
    if (streamedChars >= STREAM_FULL.length) {
      setStreamPhase('done')
      return
    }
    const t = window.setTimeout(() => setStreamedChars(c => c + 1), 12)
    return () => window.clearTimeout(t)
  }, [streamPhase, streamedChars])

  useEffect(() => {
    initialLoadTimeoutRef.current = window.setTimeout(() => {
      setIsInitialLoading(false)
      initialLoadTimeoutRef.current = null
    }, 2400)
    return () => {
      if (initialLoadTimeoutRef.current !== null) {
        window.clearTimeout(initialLoadTimeoutRef.current)
      }
      clearGenerationTimeout()
      clearResetTransitionTimeouts()
    }
  }, [])

  const buildActiveTurnContent = (): ReactNode => {
    if (activeResponseType === 'overview') {
      return (
        <div className="account-view__response-content">
          <h3 className="account-view__title">{STREAM_HEADER}</h3>
          <p className="account-view__text">{renderSegments(PARA1_SEGMENTS, STREAM_PARA1.length)}</p>
          <p className="account-view__text">{renderSegments(PARA2_SEGMENTS, STREAM_PARA2.length)}</p>
          <FeedbackRow />
          <div className="account-view__button-group">
            {FOLLOW_UP_ACTIONS.map((action, i) => (
              <button
                key={action}
                type="button"
                className="account-view__pill-btn account-view__pill-btn--stagger"
                style={{ animationDelay: `${(i + 1) * 120}ms` }}
                onClick={() => handleActionSelect(action)}
              >
                {action}
              </button>
            ))}
          </div>
        </div>
      )
    }
    if (activeResponseType === 'resp') {
      return (
        <div className="account-view__response-content">
          <h3 className="account-view__title">{RESP_HEADING}</h3>
          <p className="account-view__text">{RESP_BODY}</p>
          <SelectionTiles tiles={EXPLORE_SAVINGS_TILES} onApplyComplete={handleApplyComplete} footerBeforeApply={<FeedbackRow />} />
        </div>
      )
    }
    if (activeResponseType === 'bill-changes') {
      return (
        <div className="account-view__response-content">
          <h3 className="account-view__title">{BILL_CHANGES_HEADING}</h3>
          <p className="account-view__text">{BILL_CHANGES_BODY}</p>
          <BillChangesWidget />
          <FeedbackRow />
        </div>
      )
    }
    if (activeResponseType === 'proration') {
      return (
        <div className="account-view__response-content">
          <h3 className="account-view__title">{PRORATION_HEADING}</h3>
          {PRORATION_LINES.map((line) => (
            <p key={line} className="account-view__text account-view__text--proration">{line}</p>
          ))}
          <FeedbackRow />
        </div>
      )
    }
    return (
      <div className="account-view__response-content">
        {responseContent}
        <FeedbackRow />
      </div>
    )
  }

  const handleActionSelect = (action: string) => {
    if (chatResetAnimation !== 'idle' || isGenerating) return

    setIsOptionsMenuOpen(false)
    clearGenerationTimeout()

    // Freeze current active turn into history
    if (activeTurnAction !== null) {
      const frozenContent = buildActiveTurnContent()
      setCompletedTurns(prev => [...prev, { id: activeTurnId!, action: activeTurnAction, content: frozenContent }])
    }

    const newId = Date.now()
    setActiveTurnId(newId)
    setActiveTurnAction(action)
    setIsGenerating(true)
    setActiveResponseType(null)
    setResponseContent(null)
    setRespStreamedChars(0)
    setRespStreamPhase('idle')
    setBillChangesStreamedChars(0)
    setBillChangesStreamPhase('idle')
    setProrationStreamedChars(0)
    setProrationStreamPhase('idle')
    generationTimeoutRef.current = window.setTimeout(() => {
      setIsGenerating(false)
      const isProrationQuery = /\bproration\b/i.test(action)
      const isChangeQuery = /\bchange[sd]?\b/i.test(action)
      if (action === 'Show bill overview') {
        setActiveResponseType('overview')
        setResponseContent(
          <>
            <h3 className="account-view__title">{STREAM_HEADER}</h3>
            <p className="account-view__text">{renderSegments(PARA1_SEGMENTS, STREAM_PARA1.length)}</p>
            <p className="account-view__text">{renderSegments(PARA2_SEGMENTS, STREAM_PARA2.length)}</p>
            <FeedbackRow />
            <div className="account-view__button-group">
              {FOLLOW_UP_ACTIONS.map((followUpAction, i) => (
                <button
                  key={followUpAction}
                  type="button"
                  className="account-view__pill-btn account-view__pill-btn--stagger"
                  style={{ animationDelay: `${(i + 1) * 120}ms` }}
                  onClick={() => handleActionSelect(followUpAction)}
                >
                  {followUpAction}
                </button>
              ))}
            </div>
          </>
        )
      } else if (action === 'Explore savings' || action === 'Show ways to save') {
        setActiveResponseType('resp')
        setRespStreamPhase('streaming')
      } else if (isProrationQuery) {
        setActiveResponseType('proration')
        setProrationStreamPhase('streaming')
      } else if (isChangeQuery) {
        setActiveResponseType('bill-changes')
        setBillChangesStreamPhase('streaming')
      } else {
        setActiveResponseType('static')
        setResponseContent(
          ACTION_RESPONSES[action] ?? <p className="account-view__text">Here's what I found for you.</p>
        )
      }
      generationTimeoutRef.current = null
    }, 1800)
  }

  const handleNewChat = () => {
    setIsOptionsMenuOpen(false)
    clearGenerationTimeout()
    clearResetTransitionTimeouts()
    setChatResetAnimation('fade-out')

    resetStepTimeoutRef.current = window.setTimeout(() => {
      resetChatToDefault()
      setDefaultView('welcome')
      scrollToTop()
      setChatResetAnimation('fade-in')

      resetCompleteTimeoutRef.current = window.setTimeout(() => {
        setChatResetAnimation('idle')
        resetCompleteTimeoutRef.current = null
      }, 220)

      resetStepTimeoutRef.current = null
    }, 180)
  }

  const handleInputSubmit = () => {
    const text = inputValue.trim()
    if (!text || isGenerating || isInitialLoading) return
    setInputValue('')
    inputRef.current?.blur()
    handleActionSelect(text)
  }

  const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') handleInputSubmit()
  }

  const handleApplyComplete = (summary: MonthlySummary) => {
    onClose()
    window.setTimeout(() => {
      onOrderTransitionToOrder?.(summary)
    }, 320)
  }

  const activeTurnDone = !isGenerating && (
    activeResponseType === 'overview' ||
    activeResponseType === 'static' ||
    respStreamPhase === 'done' ||
    billChangesStreamPhase === 'done' ||
    prorationStreamPhase === 'done'
  )
  const showDefaultBody = defaultView === 'welcome'
    ? !isInitialLoading
    : streamPhase !== 'idle' && streamedChars > STREAM_HEADER.length

  return (
    <aside
      id="account-ai-drawer"
      className={`account-view__drawer ${!isOpen && !isClosing ? 'account-view__drawer--hidden' : ''} ${isClosing ? 'account-view__drawer--closing' : isOpen ? 'account-view__drawer--opening' : ''}`}
      role="dialog"
      aria-label="AI assistant"
      aria-hidden={!isOpen && !isClosing}
    >
      <div className="account-view__drawer-actions">
        <div className="account-view__menu-wrap">
          <button
            type="button"
            className="account-view__icon-btn"
            aria-label="More options"
            aria-expanded={isOptionsMenuOpen}
            aria-controls="account-view-options-menu"
            onClick={() => setIsOptionsMenuOpen((current) => !current)}
          >
            <img src={ELLIPSIS_HZ_ICON_URL} alt="" className="account-view__icon-image" />
          </button>
          {isOptionsMenuOpen && (
            <div
              id="account-view-options-menu"
              className="account-view__menu"
              role="menu"
              aria-label="Chat options"
            >
              <button
                type="button"
                className="account-view__menu-item"
                role="menuitem"
                onClick={handleNewChat}
              >
                New chat
              </button>
            </div>
          )}
        </div>
        <button
          type="button"
          className="account-view__icon-btn"
          aria-label="Close drawer"
          onClick={onClose}
        >
          <img src={CLOSE_ICON_URL} alt="" className="account-view__icon-image" />
        </button>
      </div>

      <div
        className={`account-view__scroll-area${chatResetAnimation === 'fade-out' ? ' account-view__scroll-area--fade-out' : ''}${chatResetAnimation === 'fade-in' ? ' account-view__scroll-area--fade-in' : ''}`}
        ref={scrollAreaRef}
      >
      <section className="account-view__section">
        <img src={SPARKLE_ICON_URL} alt="" className="account-view__sparkle" />
        {isInitialLoading ? (
          <div className="account-view__typing-indicator" aria-label="Loading">
            <span />
            <span />
            <span />
          </div>
        ) : (
          <h2 className="account-view__title">
            {defaultView === 'welcome'
              ? WELCOME_HEADER
              : STREAM_HEADER.slice(0, Math.min(streamedChars, STREAM_HEADER.length))}
          </h2>
        )}
      </section>

      <section className="account-view__section account-view__section--body">
        {showDefaultBody && (
          <>
        {defaultView === 'welcome' ? (
          <p className="account-view__text">
            {WELCOME_BODY}
          </p>
        ) : (
          <>
            <p className="account-view__text">
              {renderSegments(PARA1_SEGMENTS, Math.min(streamedChars - STREAM_HEADER.length, STREAM_PARA1.length))}
            </p>
            {(streamedChars > STREAM_HEADER.length + STREAM_PARA1.length || streamPhase === 'done') && (
              <p className="account-view__text">
                {renderSegments(PARA2_SEGMENTS, streamedChars - STREAM_HEADER.length - STREAM_PARA1.length)}
              </p>
            )}
          </>
        )}

        {streamPhase === 'done' && activeTurnAction === null ? (
          <>
            {defaultView !== 'welcome' && <FeedbackRow />}
            <div className="account-view__button-group">
              {(defaultView === 'welcome' ? WELCOME_ACTIONS : FOLLOW_UP_ACTIONS).map((action, i) => (
                <button
                  key={action}
                  type="button"
                  className="account-view__pill-btn account-view__pill-btn--stagger"
                  style={{ animationDelay: `${i * 120}ms` }}
                  onClick={() => handleActionSelect(action)}
                >
                  {action}
                </button>
              ))}
            </div>
          </>
        ) : streamPhase === 'done' ? (
          <>
            {completedTurns.map(turn => (
              <div key={turn.id}>
                <div className="account-view__button-group">
                  <button type="button" className="account-view__pill-btn account-view__pill-btn--selected">
                    {turn.action}
                  </button>
                </div>
                <div className="account-view__response-container account-view__response-container--done">
                  <div className="account-view__assistant-response">
                    <img src={SPARKLE_ICON_URL} alt="" className="account-view__sparkle" />
                    {turn.content}
                  </div>
                </div>
              </div>
            ))}
            <div ref={selectedActionRef}>
              <div className="account-view__button-group">
                <button type="button" className="account-view__pill-btn account-view__pill-btn--selected">
                  {activeTurnAction}
                </button>
              </div>
              <div className={`account-view__response-container${activeTurnDone ? ' account-view__response-container--done' : ''}`}>
                <div className="account-view__assistant-response">
                  <img src={SPARKLE_ICON_URL} alt="" className="account-view__sparkle" />
                  {isGenerating ? (
                    <div className="account-view__typing-indicator" aria-label="Generating response">
                      <span />
                      <span />
                      <span />
                    </div>
                  ) : activeResponseType === 'resp' ? (
                    <div className="account-view__response-content">
                      <h3 className="account-view__title">
                        {RESP_HEADING.slice(0, Math.min(respStreamedChars, RESP_HEADING.length))}
                      </h3>
                      {respStreamedChars > RESP_HEADING.length && (
                        <p className="account-view__text">
                          {RESP_BODY.slice(0, respStreamedChars - RESP_HEADING.length)}
                        </p>
                      )}
                      {respStreamPhase === 'done' && (
                        <SelectionTiles
                          tiles={EXPLORE_SAVINGS_TILES}
                          onApplyComplete={handleApplyComplete}
                          footerBeforeApply={<FeedbackRow />}
                        />
                      )}
                    </div>
                  ) : activeResponseType === 'bill-changes' ? (
                    <div className="account-view__response-content">
                      <h3 className="account-view__title">
                        {BILL_CHANGES_HEADING.slice(0, Math.min(billChangesStreamedChars, BILL_CHANGES_HEADING.length))}
                      </h3>
                      {billChangesStreamedChars > BILL_CHANGES_HEADING.length && (
                        <p className="account-view__text">
                          {BILL_CHANGES_BODY.slice(0, billChangesStreamedChars - BILL_CHANGES_HEADING.length)}
                        </p>
                      )}
                      {billChangesStreamPhase === 'done' && (
                        <>
                          <BillChangesWidget stagger />
                          <FeedbackRow />
                          <div className="account-view__button-group">
                            {FOLLOW_UP_ACTIONS.map((action, i) => (
                              <button
                                key={action}
                                type="button"
                                className="account-view__pill-btn account-view__pill-btn--stagger"
                                style={{ animationDelay: `${(i + 1) * 120}ms` }}
                                onClick={() => handleActionSelect(action)}
                              >
                                {action}
                              </button>
                            ))}
                          </div>
                        </>
                      )}
                    </div>
                  ) : activeResponseType === 'proration' ? (
                    <div className="account-view__response-content">
                      <h3 className="account-view__title">
                        {PRORATION_HEADING.slice(0, Math.min(prorationStreamedChars, PRORATION_HEADING.length))}
                      </h3>
                      {prorationStreamedChars > PRORATION_HEADING.length && (
                        <>
                          {renderStreamedParagraphs(
                            PRORATION_LINES,
                            prorationStreamedChars - PRORATION_HEADING.length,
                            'account-view__text account-view__text--proration'
                          )}
                        </>
                      )}
                      {prorationStreamPhase === 'done' && (
                        <>
                          <FeedbackRow />
                          <div className="account-view__button-group">
                            {FOLLOW_UP_ACTIONS.map((action, i) => (
                              <button
                                key={action}
                                type="button"
                                className="account-view__pill-btn account-view__pill-btn--stagger"
                                style={{ animationDelay: `${(i + 1) * 120}ms` }}
                                onClick={() => handleActionSelect(action)}
                              >
                                {action}
                              </button>
                            ))}
                          </div>
                        </>
                      )}
                    </div>
                  ) : (
                    <div className="account-view__response-content">
                      {responseContent}
                      <FeedbackRow />
                    </div>
                  )}
                </div>
              </div>
            </div>
          </>
        ) : null}
        </>
        )}
      </section>
      </div>

      <div className={`account-view__input${inputFocused ? ' account-view__input--focused' : ''}`}>
        <span className="account-view__input-icon" aria-hidden="true">
          <img src={PLUS_ICON_URL} alt="" className="account-view__input-icon-image" />
        </span>
        <input
          type="text"
          className="account-view__input-field"
          placeholder="Search or ask"
          ref={inputRef}
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onKeyDown={handleInputKeyDown}
          onFocus={() => setInputFocused(true)}
          onBlur={() => setInputFocused(false)}
          disabled={isGenerating || isInitialLoading}
          aria-label="Ask a question"
        />
        {inputValue.trim() ? (
          <button
            type="button"
            className="account-view__input-icon account-view__input-send-btn"
            aria-label="Send"
            onClick={handleInputSubmit}
          >
            <img src={SEND_ICON_URL} alt="" className="account-view__input-icon-image" />
          </button>
        ) : (
          <span className="account-view__input-icon" aria-hidden="true">
            <img src={MIC_ICON_URL} alt="" className="account-view__input-icon-image" />
          </span>
        )}
      </div>
    </aside>
  )
}