import { useState } from 'react'
import './GlobalNav.css'

const LOGO_URL = '/logo.png'
const WIFI_URL = '/wifi.svg'
const BATTERY_URL = '/battery.svg'
const SYNC_URL = 'icons/refresh.svg'
const USER_SETTINGS_URL = 'icons/settings.svg'
const TOOLS_URL = 'icons/tools.svg'
const VIDEO_URL = 'icons/video.svg'
const ASTERISK_URL = 'icons/asterisk.svg'
const KIOSK_URL = 'icons/kiosk.svg'
const STATUS_URL = 'icons/info.svg'

const TABS = ['Home', 'Account', 'Order'] as const
export type GlobalNavTab = typeof TABS[number]

interface GlobalNavProps {
  activeTab?: GlobalNavTab
  onTabChange?: (tab: GlobalNavTab) => void
}

export function GlobalNav({ activeTab: controlledTab, onTabChange }: GlobalNavProps) {
  const [internalTab, setInternalTab] = useState<GlobalNavTab>('Order')
  const activeTab = controlledTab ?? internalTab

  function handleTabClick(tab: GlobalNavTab) {
    setInternalTab(tab)
    onTabChange?.(tab)
  }

  return (
    <header className="vzw-global-nav">
      <div className="vzw-global-nav__status-bar">
        <span className="vzw-global-nav__status-left">
          <img src={WIFI_URL} alt="" className="vzw-global-nav__wifi-icon" />
          iPad
        </span>
        <span className="vzw-global-nav__status-center">3:14 PM</span>
        <span className="vzw-global-nav__status-right">
          100%
          <img src={BATTERY_URL} alt="" className="vzw-global-nav__battery-icon" />
        </span>
      </div>

      <nav className="vzw-global-nav__nav">
        <div className="vzw-global-nav__brand">
          <img src={LOGO_URL} alt="Verizon" className="vzw-global-nav__logo" />
          <div className="vzw-global-nav__store-info">
            <p className="vzw-global-nav__store-name">
              <span className="vzw-global-nav__store-name-strong">Retail</span> - MW Vision Test Location
            </p>
            <div className="vzw-global-nav__store-meta">
              <span className="vzw-global-nav__meta-item">
                <span className="vzw-global-nav__meta-label">Order Loc</span>
                <span className="vzw-global-nav__meta-value">2777301 PI M</span>
              </span>
              <span className="vzw-global-nav__meta-item">
                <span className="vzw-global-nav__meta-label">Uswin</span>
                <span className="vzw-global-nav__meta-value">FRANK22</span>
              </span>
              <span className="vzw-global-nav__meta-item">
                <span className="vzw-global-nav__meta-label">Sales ID</span>
                <span className="vzw-global-nav__meta-value">ENC01</span>
              </span>
            </div>
          </div>
        </div>

        <div className="vzw-global-nav__tabs-wrapper">
          <div className="vzw-global-nav__divider" />
          <div className="vzw-global-nav__tabs" role="tablist">
            {TABS.map((tab) => (
              <button
                key={tab}
                role="tab"
                aria-selected={activeTab === tab}
                onClick={() => handleTabClick(tab)}
                className={`vzw-global-nav__tab${activeTab === tab ? ' vzw-global-nav__tab--active' : ''}`}
              >
                {tab}
                {activeTab === tab && <span className="vzw-global-nav__tab-indicator" />}
              </button>
            ))}
          </div>
          <div className="vzw-global-nav__divider" />
        </div>

        <div className="vzw-global-nav__actions">
          <button className="vzw-global-nav__icon-btn" aria-label="Sync">
            <img src={SYNC_URL} alt="" />
          </button>
          <button className="vzw-global-nav__icon-btn" aria-label="User settings">
            <img src={USER_SETTINGS_URL} alt="" />
          </button>
          <button className="vzw-global-nav__icon-btn" aria-label="Tools">
            <img src={TOOLS_URL} alt="" />
          </button>
          <button className="vzw-global-nav__icon-btn" aria-label="Video">
            <img src={VIDEO_URL} alt="" className="vzw-global-nav__icon-video" />
          </button>
          <button className="vzw-global-nav__icon-btn" aria-label="Notes">
            <img src={ASTERISK_URL} alt="" />
          </button>
          <button className="vzw-global-nav__icon-btn" aria-label="Mobile kiosk">
            <img src={KIOSK_URL} alt="" className="vzw-global-nav__icon-kiosk" />
          </button>
          <button className="vzw-global-nav__icon-btn" aria-label="Status">
            <img src={STATUS_URL} alt="" />
          </button>
        </div>
      </nav>
    </header>
  )
}
