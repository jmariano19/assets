import { useEffect, useMemo, useState } from 'react'
import { type SelectionTileItem } from '../RightPanel/components/SelectionTiles'
import './DeviceConfigurationPage.css'

const DEFAULT_DEVICE_IMAGE = '/devices/iPhone17Pro.png'
const SCAN_ICON = '/icons/barcode.svg'

const COLORS = [
  { id: 'orange', label: 'Orange', swatch: '#E88542' },
  { id: 'blue', label: 'Blue', swatch: '#3C4670' },
  { id: 'silver', label: 'Silver', swatch: '#E5E5E5' },
]

const STORAGES = ['256 GB', '512 GB', '1 TB']

const PURCHASE_OPTIONS = [
  { id: 'monthly', title: '$8.33/mo for 36 mo', subtitle: 'Monthly payment' },
  { id: 'visa', title: '$23.05/mo (exclude tax) for 36 mo on', subtitle: 'Verizon Visa card' },
  { id: 'full', title: '$1999.99', subtitle: 'Full retail price' },
]

export function getDeviceColorLabel(colorId: string) {
  return COLORS.find(color => color.id === colorId)?.label ?? 'Silver'
}

export function getDevicePurchaseLabel(purchaseId: string) {
  return PURCHASE_OPTIONS.find(option => option.id === purchaseId)?.title ?? '$8.33/mo for 36 mo'
}

const FULFILLMENT_OPTIONS = [
  { id: 'local', title: 'Local fulfillment', subtitle: 'Available' },
  { id: 'pickup', title: 'In-store pickup', subtitle: '' },
  { id: 'shipping', title: 'Shipping', subtitle: 'Available to ship' },
]

export interface DeviceConfigurationState {
  selectedColor: string
  selectedStorage: string
  selectedPurchase: string
  selectedFulfillment: string
  deviceId: string
  simId: string
}

export function createInitialDeviceConfigurationState(): DeviceConfigurationState {
  return {
    selectedColor: 'silver',
    selectedStorage: '512 GB',
    selectedPurchase: 'monthly',
    selectedFulfillment: 'local',
    deviceId: '',
    simId: '',
  }
}

interface DeviceConfigurationPageProps {
  device?: SelectionTileItem | null
  initialState?: DeviceConfigurationState
  onStateChange?: (state: DeviceConfigurationState, hasChanges: boolean) => void
}

export function DeviceConfigurationPage({ device, initialState, onStateChange }: DeviceConfigurationPageProps) {
  const fallbackBaseline = useMemo(() => createInitialDeviceConfigurationState(), [])
  const baseline = initialState ?? fallbackBaseline
  const [state, setState] = useState<DeviceConfigurationState>(baseline)

  useEffect(() => {
    setState(baseline)
  }, [baseline])

  useEffect(() => {
    const hasChanges =
      state.selectedColor !== baseline.selectedColor
      || state.selectedStorage !== baseline.selectedStorage
      || state.selectedPurchase !== baseline.selectedPurchase
      || state.selectedFulfillment !== baseline.selectedFulfillment
      || state.deviceId !== baseline.deviceId
      || state.simId !== baseline.simId

    onStateChange?.(state, hasChanges)
  }, [baseline, onStateChange, state])

  const selectedColorLabel = getDeviceColorLabel(state.selectedColor)

  return (
    <section className="device-config-page">
      <div className="device-config-page__panel">
        <div className="device-config-page__columns">
          <div className="device-config-page__device-column">
            <h2 className="device-config-page__device-name">{device?.name ?? 'Apple iPhone 17 Pro'}</h2>
            <img src={device?.image ?? DEFAULT_DEVICE_IMAGE} alt={device?.name ?? 'Apple iPhone 17 Pro'} className="device-config-page__device-image" />
            <p className="device-config-page__sku">MG7L4LL/A</p>

            <div className="device-config-page__comparison">
              <p className="device-config-page__comparison-title">Compared to your iPhone 14 Pro</p>
              <p>Higher quality 48MP camera</p>
              <p>A larger 6.3 inch display</p>
              <p>4x faster</p>
              <p>2x storage</p>
            </div>
          </div>

          <div className="device-config-page__options-column">
            <div className="device-config-page__section">
              <p className="device-config-page__section-title">Color <span>{selectedColorLabel}</span></p>
              <div className="device-config-page__swatches">
                {COLORS.map(color => (
                  <button
                    key={color.id}
                    type="button"
                    className={`device-config-page__swatch${state.selectedColor === color.id ? ' device-config-page__swatch--selected' : ''}`}
                    style={{ background: color.swatch }}
                    aria-label={color.label}
                    onClick={() => setState(current => ({ ...current, selectedColor: color.id }))}
                  />
                ))}
              </div>
            </div>

            <div className="device-config-page__section">
              <p className="device-config-page__section-title">Storage</p>
              <div className="device-config-page__radio-group">
                {STORAGES.map(storage => (
                  <button
                    key={storage}
                    type="button"
                    className={`device-config-page__radio-box${state.selectedStorage === storage ? ' device-config-page__radio-box--selected' : ''}`}
                    onClick={() => setState(current => ({ ...current, selectedStorage: storage }))}
                  >
                    <span>{storage}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="device-config-page__section">
              <p className="device-config-page__section-title">Purchase options</p>
              <div className="device-config-page__radio-group device-config-page__radio-group--tall">
                {PURCHASE_OPTIONS.map(option => (
                  <button
                    key={option.id}
                    type="button"
                    className={`device-config-page__radio-box device-config-page__radio-box--tall${state.selectedPurchase === option.id ? ' device-config-page__radio-box--selected' : ''}`}
                    onClick={() => setState(current => ({ ...current, selectedPurchase: option.id }))}
                  >
                    <span className="device-config-page__radio-title">{option.title}</span>
                    <span className="device-config-page__radio-subtitle">{option.subtitle}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="device-config-page__section">
              <p className="device-config-page__section-title">Fulfillment options</p>
              <div className="device-config-page__radio-group device-config-page__radio-group--tall">
                {FULFILLMENT_OPTIONS.map(option => (
                  <button
                    key={option.id}
                    type="button"
                    className={`device-config-page__radio-box device-config-page__radio-box--tall${state.selectedFulfillment === option.id ? ' device-config-page__radio-box--selected' : ''}`}
                    onClick={() => setState(current => ({ ...current, selectedFulfillment: option.id }))}
                  >
                    <span className="device-config-page__radio-title">{option.title}</span>
                    {option.subtitle && <span className="device-config-page__radio-subtitle">{option.subtitle}</span>}
                  </button>
                ))}
              </div>
            </div>

            <div className="device-config-page__inputs">
              <div className="device-config-page__input-group">
                <label htmlFor="device-id">Enter Device ID</label>
                <div className="device-config-page__input-wrap">
                  <input id="device-id" type="text" value={state.deviceId} onChange={event => setState(current => ({ ...current, deviceId: event.target.value }))} />
                  <button type="button" aria-label="Scan device ID">
                    <img src={SCAN_ICON} alt="" />
                  </button>
                </div>
              </div>

              <div className="device-config-page__input-group">
                <label htmlFor="sim-id">SIM ID</label>
                <div className="device-config-page__input-wrap">
                  <input id="sim-id" type="text" value={state.simId} onChange={event => setState(current => ({ ...current, simId: event.target.value }))} />
                  <button type="button" aria-label="Scan SIM ID">
                    <img src={SCAN_ICON} alt="" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
