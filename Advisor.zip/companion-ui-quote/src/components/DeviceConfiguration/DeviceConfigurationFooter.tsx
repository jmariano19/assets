import './DeviceConfigurationFooter.css'

interface DeviceConfigurationFooterProps {
  onCancel?: () => void
  onApply?: () => void
  applyDisabled?: boolean
}

export function DeviceConfigurationFooter({ onCancel, onApply, applyDisabled = true }: DeviceConfigurationFooterProps) {
  return (
    <footer className="device-config-footer">
      <div className="device-config-footer__inner">
        <button type="button" className="device-config-footer__cancel" onClick={onCancel}>Cancel</button>
        <button
          type="button"
          className={`device-config-footer__apply${!applyDisabled ? ' device-config-footer__apply--enabled' : ''}`}
          onClick={onApply}
          disabled={applyDisabled}
        >
          Apply
        </button>
      </div>
    </footer>
  )
}
