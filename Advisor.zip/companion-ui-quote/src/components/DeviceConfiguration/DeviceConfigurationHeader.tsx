import './DeviceConfigurationHeader.css'

const BACK_URL = '/icons/left-caret.svg'

interface DeviceConfigurationHeaderProps {
  onBack?: () => void
  title?: string
}

export function DeviceConfigurationHeader({ onBack, title = 'Device configuration' }: DeviceConfigurationHeaderProps) {
  return (
    <header className="device-config-header">
      <div className="device-config-header__content">
        <button className="device-config-header__back-btn" type="button" aria-label="Back" onClick={onBack}>
          <img src={BACK_URL} alt="" />
        </button>
        <h1 className="device-config-header__title">{title}</h1>
      </div>
    </header>
  )
}
