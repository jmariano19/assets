import './Footer.css'

const SCREEN_SHARE_URL = 'icons/screen-share.svg'
// const CHEVRON_DOWN_URL = 'icons/down-caret.svg'
const CHEVRON_UP_URL   = 'icons/up-caret.svg'

interface CostItem {
  label: string
  value: string
  accent?: boolean
  skeletonLabelWidth: number
}

interface FooterProps {
  quoteLabel?: string
  currentMonthly?: string
  dueToday?: string
  estNewMonthly?: string
  monthlySavings?: string
  hasSelections?: boolean
  loading?: boolean
  onReviewQuote?: () => void
  onScreenShare?: () => void
  onQuoteToggle?: () => void
}

export function Footer({
  quoteLabel = 'Quote 1',
  currentMonthly = '$XX.XX',
  dueToday = '$0.00',
  estNewMonthly = '$XX.XX',
  monthlySavings = '$XX.XX',
  hasSelections = false,
  loading = false,
  onReviewQuote,
  onScreenShare,
  onQuoteToggle,
}: FooterProps) {
  const allCosts: CostItem[] = [
    { label: 'Current monthly', value: currentMonthly, skeletonLabelWidth: 99.5 },
    { label: 'Due today', value: dueToday, skeletonLabelWidth: 62.5 },
    { label: 'Est new monthly', value: estNewMonthly, skeletonLabelWidth: 101 },
    { label: 'Monthly savings', value: monthlySavings, accent: true, skeletonLabelWidth: 99.5 },
  ]
  const costs = hasSelections ? allCosts : allCosts.slice(0, 1)
  const pillLabel = hasSelections ? quoteLabel : 'Current'

  return (
    <footer className="vzw-footer">
      <div className="vzw-footer__inner">
        {/* Left: Quote selector + cost metrics */}
        <div className="vzw-footer__left">
          <button className="vzw-footer__quote-pill" onClick={onQuoteToggle} aria-label="Toggle quote">
            <span className="vzw-footer__quote-label">{pillLabel}</span>
            <img src={CHEVRON_UP_URL} alt="" className="vzw-footer__chevron" />
          </button>

          <div className="vzw-footer__costs">
            {loading ? (
              (hasSelections ? allCosts : allCosts.slice(0, 1)).map((item, i) => (
                <div key={item.label} className="vzw-footer__costs-group">
                  {i > 0 && <div className="vzw-footer__divider" />}
                  <div className="vzw-footer__cost">
                    <div
                      className="vzw-footer__skeleton vzw-footer__skeleton--label"
                      style={{ width: `${item.skeletonLabelWidth}px` }}
                    />
                    <div className="vzw-footer__skeleton vzw-footer__skeleton--value" />
                  </div>
                </div>
              ))
            ) : (
              costs.map((item, i) => (
                <div key={item.label} className="vzw-footer__costs-group">
                  {i > 0 && <div className="vzw-footer__divider" />}
                  <div className={`vzw-footer__cost${item.accent ? ' vzw-footer__cost--accent' : ''}`}>
                    <span className="vzw-footer__cost-label">{item.label}</span>
                    <span className="vzw-footer__cost-value">{item.value}</span>
                  </div>
                </div>
              ))
            )}
            {hasSelections && <img src={CHEVRON_UP_URL} alt="" className="vzw-footer__expand-icon" />}
          </div>
        </div>

        {/* Right: actions */}
        <div className="vzw-footer__actions">
          <button className="vzw-footer__icon-btn" onClick={onScreenShare} aria-label="Screen share">
            <img src={SCREEN_SHARE_URL} alt="" className="vzw-footer__screen-share-icon" />
          </button>
          <button className={`vzw-footer__review-btn${!hasSelections ? ' vzw-footer__review-btn--disabled' : ''}`} onClick={hasSelections ? onReviewQuote : undefined} disabled={!hasSelections}>
            Review quote
          </button>
        </div>
      </div>

      {/* Home indicator */}
      <div className="vzw-footer__home-indicator" aria-hidden="true">
        <div className="vzw-footer__home-bar" />
      </div>
    </footer>
  )
}
