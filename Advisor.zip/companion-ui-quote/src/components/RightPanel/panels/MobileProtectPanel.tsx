import { Header } from '../components/Header'
import { Actions, type Action } from '../components/Actions'
import { SelectionTiles, type SelectionTileItem } from '../components/SelectionTiles'
import { ALL_PROTECT_OPTIONS, subtitleForProtectOption, iconForProtectOption } from './AllProtectionPanel'
import './MobileProtectPanel.css'

const ICON_DECLINE = '/icons/decline.svg'
const ICON_OPTIONS = '/icons/cell-phone.svg'
const ICON_PLANS = '/icons/unlimited-plan.svg'

// The 3 summary options shown in the right panel. IDs must match ALL_PROTECT_OPTIONS.
const PROTECTION_OPTIONS: SelectionTileItem[] = [
  { id: 'add-mobile-protect', name: 'Verizon Mobile Protect', detail: '$19/mo', icon: ALL_PROTECT_OPTIONS.find(o => o.id === 'add-mobile-protect')!.icon },
  { id: 'multi-device', name: 'Verizon Mobile Protect Multi-Device 2', detail: '$38/mo', icon: ALL_PROTECT_OPTIONS.find(o => o.id === 'multi-device')!.icon },
  { id: 'decline', name: 'Decline device protection', icon: ICON_DECLINE, iconClassName: 'selection-tiles__icon--decline' },
]

interface MobileProtectPanelProps {
  resetKey?: number
  onSubtitleChange?: (subtitle: string | null) => void
  onIconChange?: (icon: string | null) => void
  selectedProtectSubtitle?: string | null
  onAllOptions?: () => void
}

export function MobileProtectPanel({ resetKey = 0, onSubtitleChange, onIconChange, selectedProtectSubtitle, onAllOptions }: MobileProtectPanelProps) {
  // Derive selectedItemId from subtitle — works for options from both this panel and AllProtectionPanel
  const selectedItemId = (() => {
    if (!selectedProtectSubtitle) return null
    // Try matching against the full options list first (covers AllProtectionPanel selections)
    const fullMatch = ALL_PROTECT_OPTIONS.find(o => subtitleForProtectOption(o) === selectedProtectSubtitle)
    if (fullMatch) {
      return PROTECTION_OPTIONS.find(p => p.id === fullMatch.id)?.id ?? null
    }
    // Fallback: match against the summary panel items (legacy format without price)
    return PROTECTION_OPTIONS.find(
      o => selectedProtectSubtitle === (o.detail ? `${o.name} • ${o.detail}` : o.name)
    )?.id ?? null
  })()

  const ACTIONS: Action[] = [
    { id: 'options', label: 'All options', icon: ICON_OPTIONS, compact: true, onClick: onAllOptions },
    { id: 'plans', label: 'Continue to plans', icon: ICON_PLANS, compact: true },
  ]

  return (
    <div className="mobile-protect-panel">
      <div className="mobile-protect-panel__content right-panel__content">
        <Header
          title="Keep devices safe"
          subtitle="Device protection plan that covers accidental damage, loss, theft, and post-warranty issues."
          titleRowClassName="mobile-protect-panel__title-row"
        />
        <SelectionTiles
          key={resetKey}
          items={PROTECTION_OPTIONS}
          selectedItemId={selectedItemId}
          onSelectionChange={item => {
            if (!item) {
              onSubtitleChange?.(null)
              onIconChange?.(null)
              return
            }
            // Use AllProtectionPanel's subtitle format for consistency
            const fullOpt = ALL_PROTECT_OPTIONS.find(o => o.id === item.id)
            if (fullOpt) {
              onSubtitleChange?.(subtitleForProtectOption(fullOpt))
              onIconChange?.(iconForProtectOption(fullOpt))
            } else {
              onSubtitleChange?.(item.detail ? `${item.name} • ${item.detail}` : item.name)
              onIconChange?.(item.id !== 'decline' ? item.icon ?? null : null)
            }
          }}
        />
      </div>
      <Actions actions={ACTIONS} />
    </div>
  )
}
