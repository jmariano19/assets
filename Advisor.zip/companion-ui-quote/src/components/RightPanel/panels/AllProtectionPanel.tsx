import { useState } from 'react'
import './AllProtectionPanel.css'

const ICON_PROTECT = '/protect-on.png'
const ICON_DECLINE = '/icons/decline.svg'
const BACK_ICON_URL = '/icons/left-caret.svg'
const CHECK_ICON_URL = '/icons/check1.svg'

type ProtectOption = {
  id: string
  name: string
  price: string
  features: string[]
  icon: string
}

export const ALL_PROTECT_OPTIONS: ProtectOption[] = [
  {
    id: 'multi-device',
    name: 'Verizon Mobile Protect Multi-Device 2',
    price: '$38/mo',
    features: ['Unlimited Claims', '$0 deductible cracked glass repairs', 'Pro on the go', '$99 damage deductible'],
    icon: ICON_PROTECT,
  },
  {
    id: 'add-mobile-protect',
    name: 'Verizon Mobile Protect',
    price: '$19/mo',
    features: ['Unlimited Claims', '$0 deductible cracked glass repairs', 'Pro on the go', '$99 damage deductible'],
    icon: ICON_PROTECT,
  },
  {
    id: 'mobile-secure',
    name: 'Mobile Secure',
    price: '$13.80/mo',
    features: ['Pro on the go', 'In-person device refresh', 'Digital Secure', 'Tech Coach', 'Call Filter'],
    icon: ICON_PROTECT,
  },
  {
    id: 'decline',
    name: 'Decline device protection',
    price: '$0.00/mo',
    features: [],
    icon: ICON_DECLINE,
  },
  {
    id: 'total-equipment',
    name: 'Total Equipment Coverage',
    price: '$12.40/mo',
    features: ['Lost, stolen, or damaged coverage', 'Next-day replacement', 'Tech Coach support'],
    icon: ICON_PROTECT,
  },
  {
    id: 'wireless-phone',
    name: 'Wireless Phone Protection',
    price: '$8.25/mo',
    features: ['Lost, stolen, or damaged coverage', 'Next-day replacement'],
    icon: ICON_PROTECT,
  },
  {
    id: 'mobile-secure-2',
    name: 'Mobile Secure',
    price: '$6.60/mo',
    features: ['Digital Secure', 'Tech Coach', 'Call Filter'],
    icon: ICON_PROTECT,
  },
]

export function subtitleForProtectOption(opt: ProtectOption): string {
  return `${opt.name} • ${opt.price}`
}

export function iconForProtectOption(opt: ProtectOption): string | null {
  return opt.id === 'decline' ? null : opt.icon
}

interface AllProtectionPanelProps {
  selectedProtectSubtitle?: string | null
  onSubtitleChange?: (subtitle: string | null) => void
  onIconChange?: (icon: string | null) => void
  onBack: () => void
  fullPage?: boolean
}

export function AllProtectionPanel({ selectedProtectSubtitle, onSubtitleChange, onIconChange, onBack, fullPage = false }: AllProtectionPanelProps) {
  const initialId = ALL_PROTECT_OPTIONS.find(o => subtitleForProtectOption(o) === selectedProtectSubtitle)?.id ?? null
  const [selectedId, setSelectedId] = useState<string | null>(initialId)

  function handleApply() {
    const opt = ALL_PROTECT_OPTIONS.find(o => o.id === selectedId) ?? null
    onSubtitleChange?.(opt ? subtitleForProtectOption(opt) : null)
    onIconChange?.(opt ? iconForProtectOption(opt) : null)
    onBack()
  }

  return (
    <div className={`all-protection-panel${fullPage ? ' all-protection-panel--full-page' : ''}`}>
      <div className="all-protection-panel__content">
        <div className="all-protection-panel__header">
          <button type="button" className="all-protection-panel__back-btn" onClick={onBack} aria-label="Back">
            <img src={BACK_ICON_URL} alt="" />
          </button>
          <h2 className="all-protection-panel__title">All protection</h2>
        </div>

        <div className="all-protection-panel__tiles-container">
          <div className="all-protection-panel__grid">
            {ALL_PROTECT_OPTIONS.map(opt => {
              const isSelected = selectedId === opt.id
              return (
                <div
                  key={opt.id}
                  className={`all-protection-panel__card${isSelected ? ' all-protection-panel__card--selected' : ''}`}
                >
                  <div className="all-protection-panel__card-body">
                    <p className="all-protection-panel__card-name">{opt.name}</p>
                    <p className="all-protection-panel__card-price">{opt.price}</p>
                    {opt.features.length > 0 && (
                      <ul className="all-protection-panel__card-features">
                        {opt.features.map(f => <li key={f}>{f}</li>)}
                      </ul>
                    )}
                  </div>
                  <div className="all-protection-panel__card-footer">
                    <button type="button" className="all-protection-panel__details-link">Details</button>
                    <button
                      type="button"
                      className={`all-protection-panel__select-btn${isSelected ? ' all-protection-panel__select-btn--selected' : ''}`}
                      onClick={() => setSelectedId(isSelected ? null : opt.id)}
                      aria-pressed={isSelected}
                    >
                      {isSelected
                        ? <img src={CHECK_ICON_URL} alt="" className="all-protection-panel__check-icon" aria-hidden="true" />
                        : 'Select'
                      }
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      <div className="all-protection-panel__footer">
        <div className="all-protection-panel__footer-inner">
          <button type="button" className="all-protection-panel__cancel-btn" onClick={onBack}>
            Cancel
          </button>
          <button
            type="button"
            className="all-protection-panel__apply-btn"
            onClick={handleApply}
            disabled={selectedId === null}
          >
            Apply
          </button>
        </div>
      </div>
    </div>
  )
}
