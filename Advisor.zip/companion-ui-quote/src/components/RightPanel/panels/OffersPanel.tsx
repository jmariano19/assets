import { Header } from '../components/Header'
import { Actions, type Action } from '../components/Actions'
import { SelectionTiles, type SelectionTileItem } from '../components/SelectionTiles'
import './OffersPanel.css'

const ICON_OFFERS = '/icons/offer.svg'
const ICON_DEVICE = '/icons/cell-phone.svg'

const ACTIONS: Action[] = [
  { id: 'apply', label: 'All offers', icon: ICON_OFFERS },
  { id: 'quote', label: 'Continue to devices', icon: ICON_DEVICE },
]

const OFFERS: SelectionTileItem[] = [
  { id: '1', name: 'Choose any myPlan, get a new iPhone on us', detail: 'w/ eligible phone trade-in & myPlan. Any condition guaranteed.', icon: ICON_OFFERS },
  { id: '2', name: 'iPhone 17. Get it on us', detail: 'Even on our lowest priced plans. With new line on myPlan. No trade-in required.', icon: ICON_OFFERS },
  { id: '3', name: 'iPhone 17 Pro Max. All out Pro. Get it for $100', detail: 'via 36 monthly bill credits. With Eligible phone trade-in. Any condition guaranteed. With new line on Unlimited Ultimate.', icon: ICON_OFFERS },
  { id: '4', name: 'Choose any myPlan, get a new iPhone on us', detail: 'w/ eligible phone trade-in & myPlan. Any condition guaranteed.', icon: ICON_OFFERS },
]

interface OffersPanelProps {
  customerName?: string
  resetKey?: number
  onSubtitleChange?: (subtitle: string | null) => void
  selectedOfferName?: string | null
}

export function OffersPanel({ customerName = 'Ben', resetKey = 0, onSubtitleChange, selectedOfferName }: OffersPanelProps) {
  const selectedOfferId = OFFERS.find(o => o.name === selectedOfferName)?.id ?? null

  return (
    <div className="offers-panel">
      <div className="offers-panel__content right-panel__content">
        <Header
          title={`Best deals for ${customerName}`}
          subtitle="Here are the top available offers. This text is intentionaly long to test how the scrolling behavior works when the content is overflowing."
          titleRowClassName="offers-panel__title-row"
        />
        <SelectionTiles
          key={resetKey}
          items={OFFERS}
          selectedItemId={selectedOfferId}
          onSelectionChange={item => onSubtitleChange?.(item ? item.name : null)}
        />
      </div>
      <Actions actions={ACTIONS} />
    </div>
  )
}
