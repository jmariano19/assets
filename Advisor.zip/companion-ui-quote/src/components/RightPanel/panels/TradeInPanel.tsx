import { Header } from '../components/Header'
import './ComingSoonPanel.css'

export function TradeInPanel() {
  return (
    <div className="coming-soon-panel">
      <div className="coming-soon-panel__content right-panel__content">
        <Header title="Coming soon" showSparkle={false} />
      </div>
    </div>
  )
}
