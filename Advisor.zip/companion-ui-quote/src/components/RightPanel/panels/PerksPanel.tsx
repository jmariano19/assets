import { useEffect, useState } from 'react'
import { Header } from '../components/Header'
import { Actions, type Action } from '../components/Actions'
import { SelectionTiles, type SelectionTileItem } from '../components/SelectionTiles'
import './PerksPanel.css'

const ICON_PERKS = '/icons/plan-perks.svg'
const ICON_TRADEIN = '/icons/cell-phone.svg'

const IMG_APPLE_MUSIC = '/thumbnails/apple_one.png'
const IMG_NETFLIX = '/thumbnails/netmax.png'
const IMG_TRAVELPASS = '/thumbnails/disney.png'

const PERKS: SelectionTileItem[] = [
  { id: 'apple-music',  name: 'Apple One',                detail: '$15/mo', savings: 'Save $4.95/mo', image: IMG_APPLE_MUSIC },
  { id: 'netflix-hbo',  name: 'Netflix & HBO Max (With Ads)', detail: '$10/mo', savings: 'Save $8.98/mo', image: IMG_NETFLIX },
  { id: 'travelpass',   name: 'Disney+, Hulu, ESPN+ (With Ads)',            detail: '$10/mo', savings: 'Save $9.99/mo', image: IMG_TRAVELPASS },
]

const ACTIONS: Action[] = [
  { id: 'all',  icon: ICON_PERKS,   label: 'All perks' },
  { id: 'next', icon: ICON_TRADEIN, label: 'Continue to trade-In' },
]

interface PerksPanelProps {
  customerName?: string
  resetKey?: number
  onSubtitleChange?: (subtitle: string | null) => void
  onIconChange?: (icon: string | null) => void
  selectedPerksText?: string | null
}

export function PerksPanel({ customerName = 'Ben', resetKey = 0, onSubtitleChange, onIconChange, selectedPerksText }: PerksPanelProps) {
  const toIds = (text: string | null | undefined) =>
    text ? text.split(' • ').map(entry => {
      const name = entry.split('~~')[0]
      return PERKS.find(p => p.name === name)?.id
    }).filter(Boolean) as string[] : []

  const [selectedIds, setSelectedIds] = useState<string[]>(toIds(selectedPerksText))

  useEffect(() => { setSelectedIds(toIds(selectedPerksText)) }, [resetKey, selectedPerksText])

  return (
    <div className="perks-panel">
      <div className="perks-panel__content right-panel__content">
        <Header
          title={`Best perks for ${customerName}`}
          subtitle={`Here are a few recommendations for ${customerName}.`}
          titleRowClassName="perks-panel__title-row"
        />
        <SelectionTiles
          key={resetKey}
          items={PERKS}
          multiSelect
          selectedItemIds={selectedIds}
          onMultiSelectionChange={items => {
            const next = items.map(i => i.id)
            setSelectedIds(next)
            const names = items.map(i => i.name)
            onSubtitleChange?.(names.length > 0 ? items.map(i => `${i.name}~~${i.detail}`).join(' • ') : null)
            const images = items.map(i => i.image).filter(Boolean) as string[]
            onIconChange?.(images.length > 0 ? images.join('|') : null)
          }}
        />
      </div>
      <Actions actions={ACTIONS} />
    </div>
  )
}
