import { Header } from '../components/Header'
import { Actions, type Action } from '../components/Actions'
import { SelectionTiles, type SelectionTileItem } from '../components/SelectionTiles'
import './DevicePanel.css'

const IMG_IPHONE_PRO = 'devices/iPhone17Pro.png'
const IMG_IPHONE_AIR = 'devices/iPhone17Air.png'
const IMG_IPHONE = 'devices/iPhone17.png'

const ICON_CELL_PHONE = '/icons/cell-phone.svg'
const ICON_SCAN = '/icons/barcode.svg'

const ACTIONS: Action[] = [
  { id: 'scan', icon: ICON_SCAN, label: '', iconOnly: true, compact: true, ariaLabel: 'Scan barcode' },
  { id: 'devices', icon: ICON_CELL_PHONE, label: 'All devices', compact: true },
]

const DEVICES: SelectionTileItem[] = [
  { id: 'iphone-pro', name: 'Apple iPhone 17 Pro', detail: '$XX/mo  |  Silver, 256 GB', image: IMG_IPHONE_PRO },
  { id: 'iphone-air', name: 'Apple iPhone 17 Air', detail: '$XX/mo  |  Silver, 256 GB', image: IMG_IPHONE_AIR },
  { id: 'iphone', name: 'Apple iPhone 17', detail: '$XX/mo  |  Silver, 256 GB', image: IMG_IPHONE },
]

interface DevicePanelProps {
  customerName?: string
  resetKey?: number
  onSubtitleChange?: (subtitle: string | null) => void
  onDeviceSelect?: (device: SelectionTileItem) => void
  selectedDeviceId?: string | null
}

export function DevicePanel({ customerName = 'Ben', resetKey = 0, onSubtitleChange, onDeviceSelect, selectedDeviceId }: DevicePanelProps) {
  return (
    <div className="device-panel">
      <div className="device-panel__content right-panel__content">
        <Header
          title={`Top device picks for ${customerName}`}
          subtitle="Based on customer information."
          titleRowClassName="device-panel__title-row"
        />
        <SelectionTiles
          key={resetKey}
          items={DEVICES}
          selectedItemId={selectedDeviceId}
          onSelectionChange={item => {
            if (item) {
              onDeviceSelect?.(item)
              return
            }
            onSubtitleChange?.(null)
          }}
        />
      </div>
      <Actions actions={ACTIONS} />
    </div>
  )
}
