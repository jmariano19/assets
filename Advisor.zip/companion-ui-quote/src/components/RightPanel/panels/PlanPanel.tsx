import { Header } from '../components/Header'
import { Actions, type Action } from '../components/Actions'
import { SelectionTiles, type SelectionTileItem } from '../components/SelectionTiles'
import './PlanPanel.css'

const ICON_PLAN = '/icons/unlimited-plan.svg'
const ICON_PERKS = '/icons/plan-perks.svg'

const PLANS: SelectionTileItem[] = [
  {
    id: 'unlimited-ultimate',
    name: 'Unlimited Ultimate',
    detail: '$XX/mo per line w/ 2 lines',
    nameColor: '#E10014',
    badge: { label: 'Best', variant: 'best' },
  },
  {
    id: 'unlimited-plus',
    name: 'Unlimited Plus',
    detail: '$XX/mo per line w/ 2 lines',
    nameColor: '#E10014',
  },
  {
    id: 'unlimited-welcome',
    name: 'Unlimited Welcome',
    detail: '$XX/mo per line w/ 2 lines',
    nameColor: '#E10014',
  },
]

const ACTIONS: Action[] = [
  { id: 'all-plans', icon: ICON_PLAN, label: 'All plans' },
  { id: 'perks', icon: ICON_PERKS, label: 'Continue to perks' },
]

interface PlanPanelProps {
  customerName?: string
  resetKey?: number
  onSubtitleChange?: (subtitle: string | null) => void
  onIconChange?: (icon: string | null) => void
  selectedPlanName?: string | null
}

export function PlanPanel({ customerName = 'Ben', resetKey = 0, onSubtitleChange, onIconChange, selectedPlanName }: PlanPanelProps) {
  const normalizedPlanName = selectedPlanName?.replace(/\s[·•]\s.*$/, '') ?? null
  const selectedPlanId = PLANS.find(plan => plan.name === normalizedPlanName)?.id ?? null

  return (
    <div className="plan-panel">
      <div className="plan-panel__content right-panel__content">
        <Header
          title="Available plan options"
          subtitle={`${customerName} currently has the Unlimited Plus Plan.`}
          titleRowClassName="plan-panel__title-row"
        />
        <SelectionTiles
          key={resetKey}
          items={PLANS}
          selectedItemId={selectedPlanId}
          onSelectionChange={item => {
            onSubtitleChange?.(item ? item.name : null)
            onIconChange?.(item ? '/thumbnails/unlimited-plan.png' : null)
          }}
        />
      </div>
      <Actions actions={ACTIONS} />
    </div>
  )
}
