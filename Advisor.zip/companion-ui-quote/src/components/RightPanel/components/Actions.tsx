export interface Action {
  id: string
  label: string
  icon: string
  iconOnly?: boolean
  compact?: boolean
  ariaLabel?: string
  onClick?: () => void
}

interface ActionsProps {
  actions: Action[]
}

export function Actions({ actions }: ActionsProps) {
  return (
    <div className="right-panel__actions">
      {actions.map(action => (
        <button
          key={action.id}
          type="button"
          className={`right-panel__action-btn${action.compact ? ' right-panel__action-btn--compact' : ''}${action.iconOnly ? ' right-panel__action-btn--icon' : ''}`}
          aria-label={action.ariaLabel}
          onClick={action.onClick}
        >
          <img src={action.icon} alt="" style={{ width: '20px', height: '20px' }} />
          {!action.iconOnly && action.label}
        </button>
      ))}
    </div>
  )
}
