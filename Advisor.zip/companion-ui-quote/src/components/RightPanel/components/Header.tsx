const SPARKLE_ICON = '/ai-icon.svg'

interface HeaderProps {
  title: string
  subtitle?: string
  showSparkle?: boolean
  titleRowClassName?: string
}

export function Header({ 
  title, 
  subtitle, 
  showSparkle = true,
  titleRowClassName = '' 
}: HeaderProps) {
  return (
    <div className="right-panel__header">
      <div className={titleRowClassName}>
        {showSparkle && <img src={SPARKLE_ICON} alt="" />}
        <h2 className="right-panel__title">{title}</h2>
      </div>
      {subtitle && <p className="right-panel__subtitle">{subtitle}</p>}
    </div>
  )
}
