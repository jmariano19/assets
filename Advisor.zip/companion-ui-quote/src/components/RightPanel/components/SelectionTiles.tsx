import { useEffect, useState } from 'react'
import './SelectionTiles.css'

export interface SelectionTileItem {
  id: string
  name: string
  detail?: string
  savings?: string
  image?: string
  icon?: string
  iconClassName?: string
  badge?: { label: string; variant: 'best' | 'current' }
  nameColor?: string
}

interface SelectionTilesProps {
  items: SelectionTileItem[]
  onSelectionChange?: (item: SelectionTileItem | null) => void
  onMultiSelectionChange?: (items: SelectionTileItem[]) => void
  selectedItemId?: string | null
  selectedItemIds?: string[]
  multiSelect?: boolean
}

export function SelectionTiles({ items, onSelectionChange, onMultiSelectionChange, selectedItemId, selectedItemIds, multiSelect = false }: SelectionTilesProps) {
  const [selectedTile, setSelectedTile] = useState<string | null>(selectedItemId ?? null)
  const [checkedSet, setCheckedSet] = useState<Set<string>>(new Set(selectedItemIds ?? []))

  useEffect(() => {
    if (selectedItemId !== undefined) {
      setSelectedTile(selectedItemId)
    }
  }, [selectedItemId])

  useEffect(() => {
    if (selectedItemIds !== undefined) {
      setCheckedSet(new Set(selectedItemIds))
    }
  }, [selectedItemIds])

  return (
    <div className="selection-tiles">
      {items.map(item => {
        const key = item.id
        const isSelected = multiSelect ? checkedSet.has(key) : selectedTile === key

        return (
          <button
            key={key}
            type="button"
            className={`selection-tiles__tile${isSelected ? ' selection-tiles__tile--selected' : ''}${!item.icon && !item.image ? ' selection-tiles__tile--no-media' : ''}`}
            onClick={() => {
              if (multiSelect) {
                const next = new Set(checkedSet)
                if (next.has(key)) next.delete(key)
                else next.add(key)
                setCheckedSet(next)
                onMultiSelectionChange?.(items.filter(i => next.has(i.id)))
              } else {
                const nextSelection = selectedTile === key ? null : key
                setSelectedTile(nextSelection)
                onSelectionChange?.(nextSelection ? item : null)
              }
            }}
          >
            {item.badge && (
              <span className={`selection-tiles__badge selection-tiles__badge--${item.badge.variant}`}>
                {item.badge.variant === 'best' && (
                  <img src="/ai-white.svg" alt="" className="selection-tiles__badge-star" aria-hidden="true" />
                )}
                {item.badge.label}
              </span>
            )}
            {item.icon
              ? (
                <div className="selection-tiles__icon-wrap">
                  <img src={item.icon} alt="" className={`selection-tiles__icon${item.iconClassName ? ` ${item.iconClassName}` : ''}`} />
                </div>
              )
              : item.image
                ? <img src={item.image} alt={item.name} className="selection-tiles__image" />
                : null
            }
            <div className="selection-tiles__text">
              <p className="selection-tiles__name" style={item.nameColor ? { color: item.nameColor } : undefined}>{item.name}</p>
              {(item.detail || item.savings) && (
                <p className="selection-tiles__detail">
                  {item.savings
                    ? <><span>{item.detail}</span><span className="selection-tiles__savings"> {item.savings}</span></>
                    : item.detail
                  }
                </p>
              )}
            </div>
            {multiSelect
              ? <div className={`selection-tiles__checkbox${isSelected ? ' selection-tiles__checkbox--checked' : ''}`} />
              : <div className={`selection-tiles__radio${isSelected ? ' selection-tiles__radio--selected' : ''}`} />
            }
          </button>
        )
      })}
    </div>
  )
}
