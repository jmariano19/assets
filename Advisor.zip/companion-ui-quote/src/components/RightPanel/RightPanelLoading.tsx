import './RightPanelLoading.css'

export function RightPanelLoading() {
  return (
    <div className="rp-loading">
      <div className="rp-loading__title">
        <div className="rp-loading__title-bar" />
        <div className="rp-loading__description-bar" />
      </div>
      <div className="rp-loading__cards">
        <div className="rp-loading__card" />
        <div className="rp-loading__card" />
        <div className="rp-loading__card" />
      </div>
    </div>
  )
}
