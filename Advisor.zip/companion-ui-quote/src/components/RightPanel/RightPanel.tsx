import { useEffect, useState } from 'react'
import { RightPanelLoading } from './RightPanelLoading'
import { DevicePanel } from './panels/DevicePanel'
import { OffersPanel } from './panels/OffersPanel'
import { MobileProtectPanel } from './panels/MobileProtectPanel'
import { PlanPanel } from './panels/PlanPanel'
import { PerksPanel } from './panels/PerksPanel'
import { TradeInPanel } from './panels/TradeInPanel'
import { AccessoriesPanel } from './panels/AccessoriesPanel'
import { ServicesPanel } from './panels/ServicesPanel'
import { type SelectionTileItem } from './components/SelectionTiles'
import './RightPanel.css'

// Asset URLs from Figma design
const ICON_CREDIT_CARD = '/icons/credit-card.svg'
const ICON_COIN = '/icons/discount.svg'
const ICON_HOME = '/icons/home-blue.svg'
const ICON_MONEY = '/icons/discount.svg'
const ICON_OFFERS = '/icons/offer.svg'
const ICON_QUOTE = '/icons/generate.svg'

const ACTIONS = [
  { id: 'offers', label: 'Start with offers', icon: ICON_OFFERS },
  { id: 'quote', label: 'Generate quote', icon: ICON_QUOTE },
]

type PanelView = 'default' | 'loading' | 'offers' | 'protect' | 'plan' | 'perks' | 'detail' | 'tradein' | 'accessories' | 'services'

interface RightPanelProps {
  selectedTile?: string | null
  onCategorySubtitleChange?: (categoryId: string, subtitle: string | null) => void
  onCategoryIconChange?: (categoryId: string, icon: string | null) => void
  categoryResetKeys?: Record<string, number>
  categorySubtitleOverrides?: Record<string, string>
  onDeviceSelect?: (device: SelectionTileItem) => void
  selectedDeviceId?: string | null
  forceLoading?: boolean
  defaultTitle?: string
  suppressGenerateQuote?: boolean
  onAllProtectionOptions?: () => void
}

const HomeBadgeIcon = () => (
  <div className="right-panel__pill-icon">
    <img src={ICON_HOME} alt="" style={{ width: '24px', height: '24px' }} />
    <div className="right-panel__badge">
      <div className="right-panel__badge-dot" />
    </div>
  </div>
)

export function RightPanel({ selectedTile, onCategorySubtitleChange, onCategoryIconChange, categoryResetKeys = {}, categorySubtitleOverrides = {}, onDeviceSelect, selectedDeviceId, forceLoading = false, defaultTitle = 'This is Ben’s current plan', suppressGenerateQuote = false, onAllProtectionOptions }: RightPanelProps) {
  const [view, setView] = useState<PanelView>('default')
  const visibleActions = suppressGenerateQuote ? ACTIONS.filter(action => action.id !== 'quote') : ACTIONS

  useEffect(() => {
    if (forceLoading) {
      setView('loading')
    }
  }, [forceLoading])

  useEffect(() => {
    if (!selectedTile) {
      setView('default')
      return
    }
    setView('loading')
    const destination: PanelView = selectedTile === 'offers'
      ? 'offers'
      : selectedTile === 'protect'
        ? 'protect'
        : selectedTile === 'plan'
          ? 'plan'
          : selectedTile === 'perks'
            ? 'perks'
            : selectedTile === 'tradein'
              ? 'tradein'
              : selectedTile === 'accessories'
                ? 'accessories'
                : selectedTile === 'services'
                  ? 'services'
                  : 'detail'
    const timer = setTimeout(() => setView(destination), 800)
    return () => clearTimeout(timer)
  }, [selectedTile])

  return (
    <div className="right-panel">
      {view === 'loading' && (
        <div className="right-panel__content">
          <RightPanelLoading />
        </div>
      )}

      {!forceLoading && view === 'offers' && (
        <OffersPanel
          resetKey={categoryResetKeys.offers ?? 0}
          onSubtitleChange={subtitle => onCategorySubtitleChange?.('offers', subtitle)}
          selectedOfferName={categorySubtitleOverrides.offers ?? null}
        />
      )}

      {!forceLoading && view === 'protect' && (
        <MobileProtectPanel
          resetKey={categoryResetKeys.protect ?? 0}
          onSubtitleChange={subtitle => onCategorySubtitleChange?.('protect', subtitle)}
          onIconChange={icon => onCategoryIconChange?.('protect', icon)}
          selectedProtectSubtitle={categorySubtitleOverrides.protect ?? null}
          onAllOptions={onAllProtectionOptions}
        />
      )}

      {!forceLoading && view === 'plan' && (
        <PlanPanel
          resetKey={categoryResetKeys.plan ?? 0}
          onSubtitleChange={subtitle => onCategorySubtitleChange?.('plan', subtitle)}
          onIconChange={icon => onCategoryIconChange?.('plan', icon)}
          selectedPlanName={categorySubtitleOverrides.plan ?? null}
        />
      )}

      {!forceLoading && view === 'perks' && (
        <PerksPanel
          resetKey={categoryResetKeys.perks ?? 0}
          onSubtitleChange={subtitle => onCategorySubtitleChange?.('perks', subtitle)}
          onIconChange={icon => onCategoryIconChange?.('perks', icon)}
          selectedPerksText={categorySubtitleOverrides.perks ?? null}
        />
      )}

      {!forceLoading && view === 'tradein' && <TradeInPanel />}

      {!forceLoading && view === 'accessories' && <AccessoriesPanel />}

      {!forceLoading && view === 'services' && <ServicesPanel />}

      {!forceLoading && view === 'detail' && (
        <DevicePanel
          resetKey={categoryResetKeys.device ?? 0}
          onSubtitleChange={subtitle => onCategorySubtitleChange?.('device', subtitle)}
          onDeviceSelect={onDeviceSelect}
          selectedDeviceId={selectedDeviceId}
        />
      )}

      {!forceLoading && view === 'default' && (
        <>
          <div className="right-panel__content">
            {/* Header */}
            <div className="right-panel__header">
              <h2 className="right-panel__title">{defaultTitle}</h2>
              <p className="right-panel__subtitle">
                Explore options on the left for devices, plans, perks, and more.
              </p>
            </div>

            {/* Facts */}
            <div className="right-panel__facts">
              <div className="right-panel__fact-group">
                <div className="right-panel__fact">
                  <img src={ICON_CREDIT_CARD} alt="" className="right-panel__fact-icon" />
                  <p className="right-panel__fact-text">8 years, 2 months</p>
                </div>
                <div className="right-panel__fact">
                  <img src={ICON_CREDIT_CARD} alt="" className="right-panel__fact-icon" />
                  <p className="right-panel__fact-text">Device limit: $750</p>
                </div>
              </div>
              <div className="right-panel__fact-group">
                <div className="right-panel__fact">
                  <img src={ICON_COIN} alt="" className="right-panel__fact-icon" />
                  <p className="right-panel__fact-text">Finance limit: $6595</p>
                </div>
                <div className="right-panel__fact">
                  <img src={ICON_CREDIT_CARD} alt="" className="right-panel__fact-icon" />
                  <p className="right-panel__fact-text">Bill-to-account: $200</p>
                </div>
              </div>
            </div>

            {/* Opportunities */}
            <div className="right-panel__opportunities">
              <p className="right-panel__opportunities-label">Opportunities</p>
              <div className="right-panel__opportunity-pills">
                <button className="right-panel__pill" type="button">
                  <HomeBadgeIcon />
                  <span>Qualifies for 5G Home</span>
                </button>
                <button className="right-panel__pill" type="button">
                  <div className="right-panel__pill-icon">
                    <img src={ICON_MONEY} alt="" style={{ width: '24px', height: '24px' }} />
                  </div>
                  <span>Discounts Available</span>
                </button>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="right-panel__actions">
            {visibleActions.map(action => (
              <button key={action.id} className="right-panel__action-btn" type="button">
                <div className="right-panel__action-icon">
                  <img src={action.icon} alt="" style={{ width: '20px', height: '20px' }} />
                </div>
                <span>{action.label}</span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
