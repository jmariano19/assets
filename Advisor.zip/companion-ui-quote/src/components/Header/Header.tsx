import './Header.css'

const BACK_URL = '/icons/left-caret.svg'
const SUPPORT_URL = '/icons/support.svg'
const SHARE_URL = '/icons/share.svg'
const CART_URL = '/icons/cart.svg'
const MORE_URL = '/icons/ellipsis.svg'
const PLUS_URL = '/icons/plus.svg'

interface HeaderProps {
  lineName?: string
  phoneNumber?: string
  linePillText?: string
  cartCount?: number
}

export function Header({
  lineName = 'Ben’s Line',
  phoneNumber = '480-299-4938',
  linePillText = '••• 4938',
  cartCount = 4,
}: HeaderProps) {

  return (
    <header className="line-header">
      <div className="line-header__content">
        <div className="line-header__left">
          <button className="line-header__icon-btn" aria-label="Back">
            <img src={BACK_URL} alt="" className="line-header__back-icon" />
          </button>
          <div className="line-header__line-info">
            <p className="line-header__title">{lineName}</p>
            <p className="line-header__subtitle">{phoneNumber}</p>
          </div>
        </div>

        <div className="line-header__mid">
          <button className="line-header__pill" type="button">{linePillText}</button>
          <button className="line-header__plus-btn" aria-label="Add line" type="button">
            <img src={PLUS_URL} alt="" />
          </button>
        </div>

        <div className="line-header__actions">
          <button className="line-header__icon-btn" aria-label="Support" type="button">
            <img src={SUPPORT_URL} alt="" />
          </button>
          <button className="line-header__icon-btn" aria-label="Share" type="button">
            <img src={SHARE_URL} alt="" />
          </button>
          <button className="line-header__icon-btn line-header__icon-btn--cart" aria-label="Cart" type="button">
            <img src={CART_URL} alt="" />
            <span className="line-header__cart-badge">{cartCount}</span>
          </button>
          <button className="line-header__icon-btn line-header__icon-btn--more" aria-label="More" type="button">
            <img src={MORE_URL} alt="" />
          </button>
        </div>
      </div>
    </header>
  )
}
