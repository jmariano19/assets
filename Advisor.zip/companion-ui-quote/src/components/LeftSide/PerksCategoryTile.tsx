import { useState } from 'react'
import { PerksThumbnail } from './PerksThumbnail'
import { LeftSideSkeleton } from './LeftSideSkeleton'
import './PerksCategoryTile.css'

interface PerkRow {
  name: string
  price: string
  image: string
}

interface PerksCategoryTileProps {
  perks: PerkRow[]
  selected?: boolean
  onSelect?: () => void
  loading?: boolean
  onClearAll?: () => void
  onClearPerk?: (perkName: string) => void
}

export function PerksCategoryTile({
  perks,
  selected = false,
  onSelect,
  loading = false,
  onClearAll,
  onClearPerk,
}: PerksCategoryTileProps) {
  const [clearing, setClearing] = useState(false)
  const [clearingPerkName, setClearingPerkName] = useState<string | null>(null)

  if (loading) return <LeftSideSkeleton />

  function dismiss() {
    setClearing(false)
    setClearingPerkName(null)
  }

  function handleConfirm(e: React.MouseEvent) {
    e.stopPropagation()
    if (clearingPerkName) {
      onClearPerk?.(clearingPerkName)
    } else {
      onClearAll?.()
    }
    dismiss()
  }

  function handleRowTrash(e: React.MouseEvent, perkName: string) {
    e.stopPropagation()
    setClearingPerkName(perkName)
    setClearing(true)
  }

  const images = perks.map(p => p.image)

  return (
    <div className="perks-tile-wrap">
      {/* Reveal panel */}
      <div className="perks-tile__reveal">
        <button
          className="perks-tile__reveal-btn"
          type="button"
          onClick={handleConfirm}
        >
          <img src="/icons/trash.svg" alt="" className="perks-tile__reveal-icon" />
          <span>Clear</span>
        </button>
      </div>

      {/* Sliding tile */}
      <div
        className={`perks-tile${selected ? ' perks-tile--selected' : ''}${clearing ? ' perks-tile--clearing' : ''}`}
        onClick={clearing ? dismiss : onSelect}
        role="button"
        tabIndex={0}
        onKeyDown={e => {
          if (e.key === 'Escape') { dismiss(); return }
          if (!clearing && (e.key === 'Enter' || e.key === ' ')) onSelect?.()
        }}

      >
        <div className="perks-tile__inner">
          {/* Thumbnail grid */}
          <div className="perks-tile__thumbnail">
            <PerksThumbnail images={images} />
          </div>

          {/* Content: title + perk rows */}
          <div className="perks-tile__content">
            <p className="perks-tile__title">Perks</p>
            <div className="perks-tile__rows">
              {perks.map((perk, i) => (
                <div key={perk.name}>
                  {i > 0 && <div className="perks-tile__divider" />}
                  <div className="perks-tile__row">
                    <p className="perks-tile__row-name">
                      {perk.name}{perk.price && <span className="perks-tile__row-price"> • {perk.price}</span>}
                    </p>
                    <button
                      className={`perks-tile__row-trash${clearing && clearingPerkName !== perk.name ? ' perks-tile__row-trash--dimmed' : ''}`}
                      type="button"
                      onClick={e => handleRowTrash(e, perk.name)}
                      aria-label={`Remove ${perk.name}`}
                    >
                      <img src="/icons/trash.svg" alt="" className="perks-tile__row-trash-icon" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
