import { CategoryTile } from './CategoryTile'
import type { CategoryTileCheck } from './CategoryTile'
import { PerksCategoryTile } from './PerksCategoryTile'
import { PerksThumbnail } from './PerksThumbnail'
import './LeftSide.css'

// Local icons from /public/icons
const ICON_OFFERS = '/icons/offer.svg'
const ICON_CELL_PHONE = '/icons/cell-phone.svg'
const ICON_MOBILE_PROTECT = '/protect-empty.png'
const ICON_UNLIMITED_PLAN = '/icons/unlimited-plan.svg'
const ICON_PERKS = '/icons/plan-perks.svg'
const ICON_EARBUD = '/icons/earbud.svg'
const ICON_SERVICES = '/icons/services.svg'

interface LeftSideProps {
  selectedTile: string | null
  onSelectTile: (id: string | null) => void
  loadingCategory?: string | null
  subtitleOverrides?: Record<string, string>
  iconOverrides?: Record<string, string>
  selectedDeviceName?: string | null
  onClearCategory?: (categoryId: string) => void
  onClearSinglePerk?: (perkName: string) => void
  suppressTagsFor?: string[]
}

export function LeftSide({ selectedTile, onSelectTile, loadingCategory = null, subtitleOverrides = {}, iconOverrides = {}, selectedDeviceName = null, onClearCategory, onClearSinglePerk, suppressTagsFor = [] }: LeftSideProps) {
  const selectedPlanName = subtitleOverrides.plan?.replace(/\s[·•]\s.*$/, '')
  const perkImages = iconOverrides.perks ? iconOverrides.perks.split('|') : []
  const perkEntries = subtitleOverrides.perks ? subtitleOverrides.perks.split(' • ') : []
  const perkRows = perkEntries.map((entry, i) => {
    const [name, price] = entry.split('~~')
    return { name, price: price ?? '', image: perkImages[i] ?? '' }
  })
  const perkIcon = perkImages.length > 0
    ? <PerksThumbnail images={perkImages} />
    : ICON_PERKS

  const suppressTag = (categoryId: string) => suppressTagsFor.includes(categoryId)
  const hasOfferSelected = !!subtitleOverrides.offers
  const offerChecks: CategoryTileCheck[] | undefined = hasOfferSelected ? [
    { label: 'Device', met: !!subtitleOverrides.device },
    { label: 'Plan', met: !!subtitleOverrides.plan },
  ] : undefined
  const offerAllMet = offerChecks?.every(c => c.met)
  const offerTag = hasOfferSelected ? (offerAllMet ? 'applied' : 'pending') as 'applied' | 'pending' : undefined
  const deviceTag = subtitleOverrides.device && !suppressTag('device') ? 'new' as const : undefined
  const protectTag = (subtitleOverrides.protect || iconOverrides.protect) ? 'new' as const : undefined
  const planTag = (selectedPlanName || iconOverrides.plan) && !suppressTag('plan') ? 'new' as const : undefined
  const perksTag = (subtitleOverrides.perks || iconOverrides.perks) && !suppressTag('perks') ? 'new' as const : undefined

  function handleSelect(id: string) {
    onSelectTile(selectedTile === id ? null : id)
  }

  return (
    <div className="left-side">
      <div className="left-side__inner">
        <CategoryTile icon={ICON_OFFERS} title="Offers" compact
          subtitle={loadingCategory === 'offers' ? '' : (subtitleOverrides.offers ?? '10+ eligible offers')}
          selected={selectedTile === 'offers'} onSelect={() => handleSelect('offers')} loading={loadingCategory === 'offers'}
          hasOverride={!!subtitleOverrides.offers} onClear={() => onClearCategory?.('offers')}
          checks={offerChecks} tag={offerTag} />
        <CategoryTile icon={iconOverrides.device ?? ICON_CELL_PHONE} title={selectedDeviceName ?? 'Device'} 
          subtitle={loadingCategory === 'device' ? '' : (subtitleOverrides.device ?? 'from $XX/mo')}
          iconFullBleed={!!iconOverrides.device}
          thumbnailFullSize={!!iconOverrides.device}
          selected={selectedTile === 'device'} onSelect={() => handleSelect('device')} loading={loadingCategory === 'device'}
          hasOverride={!!subtitleOverrides.device} onClear={() => onClearCategory?.('device')} tag={deviceTag} />
        <CategoryTile icon={loadingCategory === 'protect' ? ICON_MOBILE_PROTECT : (iconOverrides.protect ?? ICON_MOBILE_PROTECT)} title="Mobile Protect" 
          subtitle={loadingCategory === 'protect' ? '' : (subtitleOverrides.protect ?? 'Decline device protection  •  $0/mo')} iconFullBleed
          selected={selectedTile === 'protect'} onSelect={() => handleSelect('protect')} loading={loadingCategory === 'protect'}
          hasOverride={!!(subtitleOverrides.protect || iconOverrides.protect)} onClear={() => onClearCategory?.('protect')}
          hideTrashIcon tag={protectTag} />
        <CategoryTile icon={iconOverrides.plan ?? ICON_UNLIMITED_PLAN} title={selectedPlanName ?? 'Plan'}
          subtitle={loadingCategory === 'plan' ? '' : (selectedPlanName ? '$XX/mo with Auto Pay' : 'from $XX/mo with Auto Pay')}
          iconFullBleed={!!iconOverrides.plan}
          thumbnailFullSize={!!iconOverrides.plan}
          selected={selectedTile === 'plan'} onSelect={() => handleSelect('plan')} loading={loadingCategory === 'plan'}
          hasOverride={!!(selectedPlanName || iconOverrides.plan)} onClear={() => onClearCategory?.('plan')} tag={planTag} />
        {perkRows.length > 1 ? (
          <PerksCategoryTile
            perks={perkRows}
            selected={selectedTile === 'perks'}
            onSelect={() => handleSelect('perks')}
            loading={loadingCategory === 'perks'}
            onClearAll={() => onClearCategory?.('perks')}
            onClearPerk={onClearSinglePerk}
          />
        ) : (
          <CategoryTile icon={perkIcon} title="Perks"
            subtitle={loadingCategory === 'perks' ? '' : (perkRows[0] ? `${perkRows[0].name}${perkRows[0].price ? ` • ${perkRows[0].price}` : ''}` : 'from $XX/mo')}
            wrapClassName={perkRows.length === 1 ? 'category-tile-wrap--perks-single' : undefined}
            selected={selectedTile === 'perks'} onSelect={() => handleSelect('perks')} loading={loadingCategory === 'perks'}
            hasOverride={!!(subtitleOverrides.perks || iconOverrides.perks)} onClear={() => onClearCategory?.('perks')} tag={perksTag} />
        )}
        <CategoryTile icon={ICON_CELL_PHONE} title="Trade-In" subtitle="save up to $XX"
          selected={selectedTile === 'tradein'} onSelect={() => handleSelect('tradein')} />
        <CategoryTile icon={ICON_EARBUD} title="Accessories" subtitle="bundle & save"
          selected={selectedTile === 'accessories'} onSelect={() => handleSelect('accessories')} />
        <CategoryTile icon={ICON_SERVICES} title="Services" subtitle="no services added"
          selected={selectedTile === 'services'} onSelect={() => handleSelect('services')} />
      </div>
    </div>
  )
}
