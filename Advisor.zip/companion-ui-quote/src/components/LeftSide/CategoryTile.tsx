import { useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { LeftSideSkeleton } from './LeftSideSkeleton'
import './CategoryTile.css'

export interface CategoryTileCheck {
  label: string
  met: boolean
}

interface CategoryTileProps {
  icon: string | ReactNode
  title: string
  subtitle: string
  linkText?: string
  onLinkClick?: () => void
  compact?: boolean
  iconFullBleed?: boolean
  selected?: boolean
  onSelect?: () => void
  loading?: boolean
  hasOverride?: boolean
  thumbnailFullSize?: boolean
  onClear?: () => void
  wrapClassName?: string
  checks?: CategoryTileCheck[]
  tag?: 'pending' | 'applied' | 'new'
  hideTrashIcon?: boolean
}

export function CategoryTile({
  icon,
  title,
  subtitle,
  linkText,
  onLinkClick,
  compact = false,
  iconFullBleed = false,
  selected = false,
  onSelect,
  loading = false,
  hasOverride = false,
  thumbnailFullSize = false,
  onClear,
  wrapClassName,
  checks,
  tag,
  hideTrashIcon = false,
}: CategoryTileProps) {
  const [clearing, setClearing] = useState(false)
  const isDragging = useRef(false)
  const startX = useRef(0)
  const snapped = useRef(false)
  const didSwipe = useRef(false)

  const SWIPE_THRESHOLD = 30

  if (loading) return <LeftSideSkeleton />

  function handleTrash(e: React.MouseEvent) {
    e.stopPropagation()
    setClearing(true)
  }

  function handleConfirmClear(e: React.MouseEvent) {
    e.stopPropagation()
    setClearing(false)
    onClear?.()
  }

  function handlePointerDown(e: React.PointerEvent) {
    if (!hasOverride) return
    if ((e.target as HTMLElement).closest('.category-tile__trash')) return
    isDragging.current = true
    snapped.current = false
    startX.current = e.clientX
    ;(e.currentTarget as HTMLElement).setPointerCapture(e.pointerId)
  }

  function handlePointerMove(e: React.PointerEvent) {
    if (!isDragging.current || snapped.current) return
    const delta = e.clientX - startX.current
    if (delta < -SWIPE_THRESHOLD) {
      snapped.current = true
      didSwipe.current = true
      setClearing(true)
    } else if (delta > SWIPE_THRESHOLD) {
      snapped.current = true
      didSwipe.current = true
      setClearing(false)
    }
  }

  function handlePointerUp() {
    isDragging.current = false
    snapped.current = false
  }

  return (
    <div className={`category-tile-wrap${compact ? ' category-tile-wrap--compact' : ''}${hasOverride ? ' category-tile-wrap--has-override' : ''}${thumbnailFullSize ? ' category-tile-wrap--thumbnail-full' : ''}${checks ? ' category-tile-wrap--has-checks' : ''}${wrapClassName ? ` ${wrapClassName}` : ''}`}>
      {/* Reveal panel */}
      <div className="category-tile__reveal">
        <button className="category-tile__reveal-btn" type="button" onClick={handleConfirmClear}>
          <img src="/icons/trash.svg" alt="" className="category-tile__reveal-icon" />
          <span>Clear</span>
        </button>
      </div>

      {/* Sliding tile */}
      <div
        className={`category-tile${compact ? ' category-tile--compact' : ''}${selected ? ' category-tile--selected' : ''}${clearing ? ' category-tile--clearing' : ''}`}
        onClick={(e) => {
          if (didSwipe.current) { didSwipe.current = false; return }
          if (clearing) {
            if ((e.target as HTMLElement).closest('.category-tile__trash')) return
            setClearing(false)
          } else {
            onSelect?.()
          }
        }}
        role="button"
        tabIndex={0}
        onKeyDown={e => {
          if (e.key === 'Escape') { setClearing(false); return }
          if (!clearing && (e.key === 'Enter' || e.key === ' ')) onSelect?.()
        }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
      >
        {linkText && (
          <button className="category-tile__link" type="button" onClick={onLinkClick}>
            {linkText}
          </button>
        )}
        <div className="category-tile__inner">
          <div className="category-tile__thumbnail">
            {iconFullBleed && typeof icon === 'string' ? (
              <img src={icon} alt="" className="category-tile__thumbnail-img" />
            ) : typeof icon === 'string' ? (
              <img src={icon} alt="" className="category-tile__icon" />
            ) : (
              icon
            )}
          </div>
          <div className="category-tile__info">
            <div className="category-tile__title-row">
              <p className="category-tile__title">{title}</p>
              {tag && (
                <span className={`category-tile__tag category-tile__tag--${tag}`}>
                  {tag === 'applied' ? 'Applied' : tag === 'new' ? 'New' : 'Pending'}
                </span>
              )}
            </div>
            <p className="category-tile__subtitle">{subtitle}</p>
            {checks && checks.length > 0 && (
              <div className="category-tile__checks">
                {checks.map(check => (
                  <div key={check.label} className={`category-tile__check${check.met ? ' category-tile__check--met' : ''}`}>
                    {check.met ? (
                      <img src="/icons/checkmark-green.svg" alt="" className="category-tile__check-icon" />
                    ) : (
                      <svg className="category-tile__check-dot" width="6" height="6" viewBox="0 0 7 7" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="3.5" cy="3.5" r="3.5" fill="#DDDAD4"/>
                      </svg>
                    )}
                    <span className="category-tile__check-label">{check.label}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
          {hasOverride && !hideTrashIcon && (
            <button
              className="category-tile__trash"
              type="button"
              onClick={clearing ? (e) => { e.stopPropagation(); setClearing(false) } : handleTrash}
              aria-label="Remove selection"
            >
              <img src="/icons/trash.svg" alt="" className="category-tile__trash-icon" />
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
