import './PerksThumbnail.css'

interface PerksThumbnailProps {
  images: string[]
}

export function PerksThumbnail({ images }: PerksThumbnailProps) {
  if (images.length === 0) return null

  if (images.length === 1) {
    return (
      <img
        src={images[0]}
        alt=""
        className="perks-thumbnail__single"
      />
    )
  }

  // 2×2 grid — show only actual images, up to 4
  const cells = images.slice(0, 4)

  return (
    <div className="perks-thumbnail__grid">
      {cells.map((src, i) => (
        <img key={i} src={src} alt="" className="perks-thumbnail__grid-img" />
      ))}
    </div>
  )
}
