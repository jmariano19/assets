import './LeftSideSkeleton.css'

export function LeftSideSkeleton() {
  return <div className="left-side-skeleton__tile" />
}
