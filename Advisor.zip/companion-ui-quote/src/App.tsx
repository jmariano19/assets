import { useState } from 'react'
import { GlobalNav } from './components/GlobalNav/GlobalNav'
import { type GlobalNavTab } from './components/GlobalNav/GlobalNav'
import { Header } from './components/Header/Header'
import { Footer } from './components/Footer/Footer'
import { LeftSide } from './components/LeftSide/LeftSide'
import { RightPanel } from './components/RightPanel/RightPanel'
import { type SelectionTileItem } from './components/RightPanel/components/SelectionTiles'
import { DeviceConfigurationHeader } from './components/DeviceConfiguration/DeviceConfigurationHeader'
import { DeviceConfigurationPage, createInitialDeviceConfigurationState, getDeviceColorLabel, getDevicePurchaseLabel, type DeviceConfigurationState } from './components/DeviceConfiguration/DeviceConfigurationPage'
import { DeviceConfigurationFooter } from './components/DeviceConfiguration/DeviceConfigurationFooter'
import { AccountView } from './components/AccountView/AccountView'
import { AccountTabs, type AccountTab } from './components/AccountView/AccountTabs'
import { AccountHelpView } from './components/AccountView/AccountHelpView'
import { AllProtectionPanel } from './components/RightPanel/panels/AllProtectionPanel'
import './App.css'

type AppPage = 'quote-builder' | 'device-configuration' | 'account' | 'all-protection'

function normalizePublicAssetPath(path: string) {
  if (path.startsWith('http://') || path.startsWith('https://') || path.startsWith('/')) {
    return path
  }
  return `/${path}`
}

function fmtCurrency(n: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2 }).format(n)
}

function App() {
  const SEEDED_ORDER_TAGS = ['device', 'plan']
  const [activeTab, setActiveTab] = useState<GlobalNavTab>(
    () => (sessionStorage.getItem('activeTab') as GlobalNavTab | null) ?? 'Order'
  )
  const [activePage, setActivePage] = useState<AppPage>(
    () => (sessionStorage.getItem('activePage') as AppPage | null) ?? 'quote-builder'
  )
  const [activeAccountTab, setActiveAccountTab] = useState<AccountTab>('account-help')
  const [isAccountFadingOut, setIsAccountFadingOut] = useState(false)
  const [isOrderFadingIn, setIsOrderFadingIn] = useState(false)
  const [showUpdatedOrderState, setShowUpdatedOrderState] = useState(false)
  const [openDrawerSignal, setOpenDrawerSignal] = useState<number | null>(null)
  const [monthlySummary, setMonthlySummary] = useState<{ previousMonthlyTotal: number; newMonthlyTotal: number; totalSavings: number } | null>(null)
  const [selectedTile, setSelectedTile] = useState<string | null>(null)
  const [selectedDevice, setSelectedDevice] = useState<SelectionTileItem | null>(null)
  const [selectedDeviceId, setSelectedDeviceId] = useState<string | null>(null)
  const [appliedDeviceName, setAppliedDeviceName] = useState<string | null>(null)
  const [deviceConfigurationState, setDeviceConfigurationState] = useState<DeviceConfigurationState>(createInitialDeviceConfigurationState)
  const [loadingCategory, setLoadingCategory] = useState<string | null>(null)
  const [categorySubtitleOverrides, setCategorySubtitleOverrides] = useState<Record<string, string>>({})
  const [categoryIconOverrides, setCategoryIconOverrides] = useState<Record<string, string>>({})
  const [categoryResetKeys, setCategoryResetKeys] = useState<Record<string, number>>({})

  function handleCategorySubtitleChange(categoryId: string, subtitle: string | null) {
    setLoadingCategory(categoryId)
    setTimeout(() => setLoadingCategory(null), 500)
    setCategorySubtitleOverrides(current => {
      if (!subtitle) {
        const { [categoryId]: _removed, ...rest } = current
        return rest
      }
      return { ...current, [categoryId]: subtitle }
    })
  }

  function handleCategoryIconChange(categoryId: string, icon: string | null) {
    setLoadingCategory(categoryId)
    setTimeout(() => setLoadingCategory(null), 500)
    setCategoryIconOverrides(current => {
      if (!icon) {
        const { [categoryId]: _removed, ...rest } = current
        return rest
      }
      return { ...current, [categoryId]: icon }
    })
  }

  function handleClearCategory(categoryId: string) {
    handleCategorySubtitleChange(categoryId, null)
    handleCategoryIconChange(categoryId, null)
    setCategoryResetKeys(current => ({ ...current, [categoryId]: (current[categoryId] ?? 0) + 1 }))
    if (categoryId === 'device') {
      setSelectedDevice(null)
      setSelectedDeviceId(null)
      setAppliedDeviceName(null)
    }
  }

  function handleClearSinglePerk(perkName: string) {
    const entries = (categorySubtitleOverrides.perks ?? '').split(' • ').filter(e => e && e.split('~~')[0] !== perkName)
    const images = (categoryIconOverrides.perks ?? '').split('|').filter((_, i) => {
      const allEntries = (categorySubtitleOverrides.perks ?? '').split(' • ')
      return allEntries[i]?.split('~~')[0] !== perkName
    })
    setCategorySubtitleOverrides(current => {
      if (entries.length === 0) { const { perks: _, ...rest } = current; return rest }
      return { ...current, perks: entries.join(' • ') }
    })
    setCategoryIconOverrides(current => {
      if (images.length === 0) { const { perks: _, ...rest } = current; return rest }
      return { ...current, perks: images.join('|') }
    })
  }

  function handleDeviceSelect(device: SelectionTileItem) {
    setSelectedDevice(device)
    setDeviceConfigurationState(createInitialDeviceConfigurationState())
    setActivePage('device-configuration')
  }

  function handleApplyDeviceConfiguration() {
    if (!selectedDevice) {
      setActivePage('quote-builder')
      return
    }

    const colorLabel = getDeviceColorLabel(deviceConfigurationState.selectedColor)
    const purchaseLabel = getDevicePurchaseLabel(deviceConfigurationState.selectedPurchase)
    const subtitle = `${colorLabel} • ${deviceConfigurationState.selectedStorage} • ${purchaseLabel}`

    handleCategorySubtitleChange('device', subtitle)
    handleCategoryIconChange('device', selectedDevice.image ? normalizePublicAssetPath(selectedDevice.image) : null)
    setSelectedDeviceId(selectedDevice.id)
    setAppliedDeviceName(selectedDevice.name)
    setSelectedTile('device')
    setActivePage('quote-builder')
  }

  function handleBackToQuoteBuilder() {
    setActivePage('quote-builder')
  }

  function handleOrderTransitionFromAccount(summary: { previousMonthlyTotal: number; newMonthlyTotal: number; totalSavings: number }) {
    setMonthlySummary(summary)
    const ACCOUNT_FADE_OUT_MS = 300
    const HANDOFF_DELAY_MS = 600

    setIsAccountFadingOut(true)
    setOpenDrawerSignal(null)
    setSelectedDeviceId('iphone-pro')
    setAppliedDeviceName('Apple iPhone 17 Pro')
    setCategorySubtitleOverrides(current => ({
      ...current,
      device: 'Silver • 256GB • $33.33/mo',
      plan: 'Unlimited Plus',
      perks: 'Disney+, Hulu, ESPN+ (With Ads)~~$10/mo',
    }))
    setCategoryIconOverrides(current => ({
      ...current,
      device: '/devices/iPhone17Pro.png',
      plan: '/thumbnails/unlimited-plan.png',
      perks: '/thumbnails/disney.png',
    }))
    setShowUpdatedOrderState(true)

    window.setTimeout(() => {
      setActiveTab('Order')
      setActivePage('quote-builder')
      setIsAccountFadingOut(false)

      setIsOrderFadingIn(true)

      window.setTimeout(() => {
        setIsOrderFadingIn(false)
      }, 420)
    }, ACCOUNT_FADE_OUT_MS + HANDOFF_DELAY_MS)
  }

  function handleTabChange(tab: GlobalNavTab) {
    setActiveTab(tab)
    sessionStorage.setItem('activeTab', tab)
    if (tab === 'Account') {
      setIsOrderFadingIn(false)
      setActivePage('account')
      sessionStorage.setItem('activePage', 'account')
    } else if (tab === 'Home' || tab === 'Order') {
      setActivePage('quote-builder')
      sessionStorage.setItem('activePage', 'quote-builder')
    }
  }

  return (
    <div className="app-layout">
      <GlobalNav activeTab={activeTab} onTabChange={handleTabChange} />
      {activePage === 'account' && (
        <AccountTabs activeTab={activeAccountTab} onTabChange={setActiveAccountTab} />
      )}
      {activePage === 'quote-builder'
        ? <Header />
        : activePage === 'device-configuration'
        ? <DeviceConfigurationHeader onBack={handleBackToQuoteBuilder} />
        : activePage === 'all-protection'
        ? <DeviceConfigurationHeader title="All protection" onBack={() => setActivePage('quote-builder')} />
        : null
      }

      <main className={`app-main${activePage === 'device-configuration' || activePage === 'all-protection' ? ' app-main--device-configuration' : ''}${activePage === 'account' ? ' app-main--account' : ''}`}>
        {activePage === 'quote-builder' && (
          <div className={`app-main__content${isOrderFadingIn ? ' app-main__content--fade-in' : ''}`}>
            <LeftSide
              selectedTile={selectedTile}
              onSelectTile={setSelectedTile}
              loadingCategory={loadingCategory}
              subtitleOverrides={categorySubtitleOverrides}
              iconOverrides={categoryIconOverrides}
              selectedDeviceName={appliedDeviceName}
              onClearCategory={handleClearCategory}
              onClearSinglePerk={handleClearSinglePerk}
              suppressTagsFor={showUpdatedOrderState ? SEEDED_ORDER_TAGS : []}
            />
            <RightPanel
              selectedTile={selectedTile}
              onCategorySubtitleChange={handleCategorySubtitleChange}
              onCategoryIconChange={handleCategoryIconChange}
              categoryResetKeys={categoryResetKeys}
              categorySubtitleOverrides={categorySubtitleOverrides}
              onDeviceSelect={handleDeviceSelect}
              selectedDeviceId={selectedDeviceId}
              defaultTitle={showUpdatedOrderState ? 'This is Ben’s updated plan' : 'This is Ben’s current plan'}
              suppressGenerateQuote={showUpdatedOrderState}
              onAllProtectionOptions={() => setActivePage('all-protection')}
            />
          </div>
        )}

        {activePage === 'all-protection' && (
          <AllProtectionPanel
            selectedProtectSubtitle={categorySubtitleOverrides.protect ?? null}
            onSubtitleChange={subtitle => handleCategorySubtitleChange('protect', subtitle)}
            onIconChange={icon => handleCategoryIconChange('protect', icon)}
            onBack={() => setActivePage('quote-builder')}
            fullPage
          />
        )}

        {activePage === 'device-configuration' && (
          <DeviceConfigurationPage
            key={selectedDevice?.id ?? 'device-config'}
            device={selectedDevice}
            onStateChange={(state) => {
              setDeviceConfigurationState(state)
            }}
          />
        )}

        {activePage === 'account' && (
          <div className={`app-account-shell${isAccountFadingOut ? ' app-account-shell--fade-out' : ''}`}>
            {activeAccountTab === 'account-help' && (
              <AccountHelpView onAnalyzeBill={() => setOpenDrawerSignal(prev => (prev ?? 0) + 1)} />
            )}
            <AccountView
              showEntryPoint={false}
              openDrawerSignal={openDrawerSignal}
              onOrderTransitionToOrder={handleOrderTransitionFromAccount}
            />
          </div>
        )}
      </main>

      {activePage === 'quote-builder' && (
        <Footer
          hasSelections={Object.keys(categorySubtitleOverrides).length > 0 || Object.keys(categoryIconOverrides).length > 0}
          loading={loadingCategory !== null}
          onReviewQuote={() => alert('Review quote clicked')}
          currentMonthly={monthlySummary ? fmtCurrency(monthlySummary.previousMonthlyTotal) : undefined}
          estNewMonthly={monthlySummary ? fmtCurrency(monthlySummary.newMonthlyTotal) : undefined}
          monthlySavings={monthlySummary ? fmtCurrency(monthlySummary.totalSavings) : undefined}
        />
      )}
      {activePage === 'device-configuration' && (
        <DeviceConfigurationFooter
          onCancel={handleBackToQuoteBuilder}
          onApply={handleApplyDeviceConfiguration}
          applyDisabled={false}
        />
      )}
    </div>
  )
}

export default App
